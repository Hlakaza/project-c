import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'xmlToJson'
})
export class XmlToJsonPipe implements PipeTransform {
  xmlToJson(xml) {
    var obj = {};
    if (xml.nodeType == 1) {
      if (xml.attributes.length > 0) {
        obj["NodeAttributes"] = {};
        for (var j = 0; j < xml.attributes.length; j++) {
          var attribute = xml.attributes.item(j);
          obj["NodeAttributes"][attribute.nodeName] = attribute.nodeValue;
        }
      }
    } else if (xml.nodeType == 3) {
      obj = xml.nodeValue;
    }

    if (xml.hasChildNodes()) {
      for (var i = 0; i < xml.childNodes.length; i++) {

        var item = xml.childNodes.item(i);
        var nodeName = item.nodeName;

        if (typeof (obj[nodeName]) == "undefined") {
          obj[nodeName] = this.xmlToJson(item);
        } else {
          if (typeof (obj[nodeName].push) == "undefined") {
            var old = obj[nodeName];
            obj[nodeName] = [];
            obj[nodeName].push(old);
          }
          obj[nodeName].push(this.xmlToJson(item));
        }

      }
    }
    
    return obj;
  }


  transform(value: any): any {
    let parseXml: any;
    let parsedXml: any;
    if (typeof (<any>window).DOMParser != "undefined") {
      parseXml = new (<any>window).DOMParser().parseFromString(value, "text/xml");
      parsedXml = this.xmlToJson(parseXml);
    }
    else if (typeof (<any>window).ActiveXObject != "undefined" && new (<any>window).ActiveXObject("Microsoft.XMLDOM")) {
      var xmlDoc = new (<any>window).ActiveXObject("Microsoft.XMLDOM");
      xmlDoc.async = "false";
      parseXml = xmlDoc.loadXML(value);
      parsedXml = this.xmlToJson(parseXml);
    } else {
      throw new Error("No XML parser found");
    }
    return parsedXml;
  }

}
