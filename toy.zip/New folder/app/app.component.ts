import { Component, OnInit, AfterViewInit } from '@angular/core';
import { AuthService } from './services/auth.service';
import { Subscription } from 'rxjs/Subscription';
import { Router, Routes, ActivatedRoute, NavigationEnd } from '@angular/router';
import 'rxjs/add/operator/filter';
import { ContentService } from './services/content.service';
import { UserService } from './services/user.service';
import { AccountService } from './services/account.service';
import { GlobalInfoService } from './services/global-info.service';
import { RegistrationService } from './services/registration.service';
import { RouteDataService } from './services/route-data.service';
import { UrlSegment } from '@angular/router/src/url_tree';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})


export class AppComponent implements AfterViewInit {
  host: any = (<any>window).global.request.host;
  constructor(
    private router: Router,
    private auth: AuthService,
    private copy: ContentService,
    private user: UserService,
    private acct: AccountService,
    private globalinfo: GlobalInfoService,
    private routeData: RouteDataService
  ) {

    if ((<any>window).global.sitemap !== undefined) {
      const routes = this.navBuilder((<any>window).global.sitemap);
      this.router.resetConfig(routes);
      // this.subscriptionCopy = this.copy.getResourceString(this.host, 'casino').subscribe(res => {
      //   console.log(res);
      // });

      this.globalinfo.getMetaData().subscribe(
        res => {
          if (res['CountriesInLanguage'][0].CC) {
            this.user.setUser('LangCode', res['CountriesInLanguage'][0].CC);
            this.acct.setAcctProperty('CurrencyCode', res['CurrenciesInLanguage'][0].PCC);
          }

        }
      );
      this.globalinfo.getRequestMetaData().subscribe(
        res => {
          this.user.setUser('CasinoCode', this.globalinfo.metaData.CasinoId);
        }
      );
    }
  }

  ngAfterViewInit() {
    this.routeData.getAlias();
  }

  navBuilder(arr): Routes {
    const navArr = [];
    navArr.push({ path: 'btag-', redirectTo: '', pathMatch: 'prefix' });
    const filterArr = (globalArr: any) => {
      globalArr.filter((value) => {
        navArr.push(
          {
            path: value.P.substring(1, value.P.length - 1) === 'Home' ? '' : value.P.substring(1, value.P.length - 1),
            component: AppComponent,
            data: { value: value.PG, title: value.PN, alias: value.A, pageTitle: value.C }
          });

        if (value.CH.length > 0) {
          filterArr(value.CH);
        }
      });

    };
    filterArr(arr);
    navArr.push({ path: 'Home', redirectTo: '', pathMatch: 'full' });
    navArr.push({ path: '**', redirectTo: '404' });
    return navArr;
  }
}

