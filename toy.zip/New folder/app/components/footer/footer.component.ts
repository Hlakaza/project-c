import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { RegistrationService } from '../../services/registration.service';
import { GlobalInfoService } from '../../services/global-info.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  linkFacebook = '';
  nodeChildren = [];
  linkBlog = '';
  linkTwitter = '';
  linkInstagram = '';
  linkPinterest = '';
  sitemap: any = (<any>window).global.sitemap;
  navListArr: any;
  constructor(
    private user: UserService,
    private globalinfo: GlobalInfoService
  ) { }

  ngOnInit() {

    this.navListArr = (<any>window).global.sitemap.filter((value) => {
      return value.TN;
    });

    this.globalinfo.getMetaData().subscribe(
      res => {
        res['BrandExternalApplications'].map(item => {
          if (item.ExternalApplicationType === 'Facebook') {
            this.linkFacebook = item.ExternalApplicationUrl;
          }
          if (item.ExternalApplicationType === 'Blog') {
            this.linkBlog = item.ExternalApplicationUrl;
          }
          if (item.ExternalApplicationType === 'Twitter') {
            this.linkTwitter = item.ExternalApplicationUrl;
          }
          if (item.ExternalApplicationType === 'Instagram') {
            this.linkInstagram = item.ExternalApplicationUrl;
          }
          if (item.ExternalApplicationType === 'Pinterest') {
            this.linkPinterest = item.ExternalApplicationUrl;
          }
        });
      }
    );
  }

}
