import { Component, OnInit } from '@angular/core';
import { RouteDataService } from '../../services/route-data.service';

@Component({
  selector: 'app-site-map',
  templateUrl: './site-map.component.html',
  styleUrls: ['./site-map.component.scss']
})
export class SiteMapComponent implements OnInit {
  sitemap: any = (<any>window).global.sitemap;
  navListArr: any;
  isSiteMap = false;
  constructor(private routeData: RouteDataService) { }

  ngOnInit() {
    this.routeData.urlData.subscribe(urlData => {
      if (urlData.length > 0) {
        if (urlData[0].path === 'Mappa-Del-Sito') {
          this.isSiteMap = true;
        } else {
          this.isSiteMap = false;
        }
      } else {
        this.isSiteMap = false;
      }
    });

    this.navListArr = (<any>window).global.sitemap.filter((value) => {
      return value.isSiteMap;
    });
  }

}
