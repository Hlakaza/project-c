import { Component, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-navigation-block',
  templateUrl: './navigation-block.component.html',
  styleUrls: ['./navigation-block.component.scss']
})
export class NavigationBlockComponent implements AfterViewInit {
  navListArr: any;
  constructor() {
    this.navListArr = (<any>window).global.sitemap.filter((value) => {
      return value.TN;
    });
   }

  ngAfterViewInit() {}

}
