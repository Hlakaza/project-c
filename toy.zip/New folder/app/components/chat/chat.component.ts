import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { ChatService } from '../../services/chat.service';
import { UserService } from '../../services/user.service';
import { AccountService } from '../../services/account.service';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/interval';

import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/debounceTime';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss']
})
export class ChatComponent implements OnInit, OnDestroy {
  showChat = false;
  isMobile: boolean;
  agent: string;
  private date;
  private messages: any;
  private display = [];
  private intevalAPICall;

  model: string;
  modelChanged: Subject<string> = new Subject<string>();
  @ViewChild('msgField') firstNameElement: ElementRef;

  chatForm = new FormGroup({
    name: new FormControl(),
    email: new FormControl()
  });

  chatMsgForm = new FormGroup({
    textMsg: new FormControl(),
  });

  genesysChatParams = {
    serviceId: null,
    chatSessionId: null,
    transcriptPosition: null,
    chatActive: false,
    messageId: null,
    messageState: null
  };

  constructor(
    private fb: FormBuilder,
    private chat: ChatService,
    private user: UserService,
    private account: AccountService
  ) {
    this.messages = [];
    this.date = new Date();
    this.agent = '';

    this.modelChanged
      .debounceTime(300) // wait 300ms after the last event before emitting last event
      .subscribe(model => {

        this.chat.startTyping()
          .subscribe(
          res => { },
          err => { }
          );
      });

    this.chat.getMessage().subscribe(
      value => {

        if (value === 'DISCONNECTED') {
          this.intevalAPICall.unsubscribe();
        } else {

          if (value.transcriptToShow) {

            value.transcriptToShow.map(val => {

              if ((val[0] === 'Notice.Joined') && (val[4] === 'AGENT')) {
                this.agent = val[1];
              }

              this.messages.push(val);
            });
          }
        }
      }
    );
  }

  ngOnInit() {
    this.chatForm = this.fb.group({
      name: ['', Validators.required],
      email: ['']
    });

    this.chatMsgForm = this.fb.group({
      textMsg: ['', Validators.required]
    });

    this.isMobile = (<any>window).global.request.device.isMobile;
    this.showChat = false;

    this.display = [];

    const storedData = this.getItem('genesysChatParams');

    if (storedData) {
      this.genesysChatParams = JSON.parse(storedData);

      this.showChat = true;
      this.display = [];
      this.display['in'] = true;

      this.chat.refreshMsg(this.genesysChatParams.serviceId, this.genesysChatParams.transcriptPosition)
        .subscribe(
          res => {
            this.chat.pollMessageSuccess(res);
          },
          err => {}
        );
    }


  }

  toggle() {
    this.showChat = !this.showChat;

    this.display = [];
    this.display['start'] = true;
  }

  initiate() {

    if (this.chatForm.value.name) {

      this.chat.initiateChat()
        .subscribe(
        res => {
          this.genesysChatParams.serviceId = res['_id'];
          this.startChat(this.chatForm.value, res['_id']);
          this.display = [];
          this.display['in'] = true;
        },
        err => { }
        );
    }
  }

  startChat(data, id) {

    const chatParams = {
      brandCode: this.user.getUser().BrandCode || '',
      langCode: this.user.getUser().LangCode || '',
      isMobile: this.isMobile || false,
      accountId: this.account.getAcctProperty('accountId') || 'Not logged in',
      skill: 'vdv',
      casinoId: this.user.getUser().CasinoCode || 2183,
      countryCode: this.account.getAcctProperty('CurrencyCode') || 'za',
      ipAddress: '41.222.104.227',
      isAuth: !!this.user.getUser().AuthToken || 'Not logged in',
      name: data.name || 'UNKNOWN'
    };

    this.chat.startChat(id, chatParams)
      .subscribe(
        res => {

          if (res['chatIxnState'] === 'DISCONNECTED') {
            this.end();
            return;
          }

          this.genesysChatParams.chatSessionId = res['chatSessionId'];
          this.genesysChatParams.transcriptPosition = res['transcriptPosition'];
          this.genesysChatParams.chatActive = true;

          this.chat.pollMessageSuccess(res);
          setTimeout(this.pollChatMessage(), 2000);

          this.storeItem('genesysChatParams', JSON.stringify(this.genesysChatParams));
        },
        err => { console.log(err); }
      );
  }

  toggleTyping(text: string) {

    if (text.length > 2) {
      this.modelChanged.next(text);
    }
  }


  sendChatMessage(msg) {

    this.chat.sendChatMessage(msg)
      .subscribe(
        res => {
          this.chatMsgForm.value.textMsg = '';
          this.chat.pollMessageSuccess(res);
        },
        err => { console.log('error', err); }
      );
  }

  pollChatMessage() {

    this.intevalAPICall = Observable.interval(5000).subscribe(() => {
      this.chat.pollChatMessages()
        .subscribe(
          res => {
            this.chat.pollMessageSuccess(res);
          },
          err => { console.log('error', err); }
        );
    });

  }

  end() {

    if (this.genesysChatParams.chatActive) {
      this.display = [];
      this.display['end'] = true;

      this.chat.endChat()
        .subscribe(
          res => {
            this.genesysChatParams.chatActive = false;
            this.chat.pollMessageSuccess(res);
            this.intevalAPICall.unsubscribe();
            this.removeItem('genesysChatParams');
          },
          err => { this.removeItem('genesysChatParams'); }
        );
    }
  }

  ngOnDestroy() {
    this.intevalAPICall.unsubscribe();
  }

  storeItem(name, value) {
    localStorage.setItem(name, value);
  }

  getItem(name) {
    return localStorage.getItem(name);
  }

  removeItem(name) {
    localStorage.removeItem(name);
  }

  removeAllItems() {
    for (let i = 0; i < localStorage.length; i++) {
      localStorage.removeItem(localStorage.key(i));
    }
  }

}
