import { Component, OnInit, OnDestroy, Renderer2 } from '@angular/core';
import { ModalService } from '../../services/modal.service';
import { ActivatedRoute } from '@angular/router';
import { ContentService } from '../../services/content.service';
@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements OnInit, OnDestroy {
  // Clear all on load
  modals = [];
  modalToggle = [];
  modalStyles = {};
  modalContent: any;
  modalGameId = '';
  modalUrl = '';
  resourceStrings: any = {};
  visible = false;

  constructor(private modal: ModalService, private render: Renderer2, private route: ActivatedRoute, private copy: ContentService) {
    this.copy.resourceStringPackEmit.subscribe(res => {
      this.resourceStrings = res;
    });
    this.copy.getResourceStringValue('casino.myaccount');
    this.copy.getResourceStringValue('casino.forgot');
    this.copy.getResourceStringValue('casino.login');
    this.copy.getResourceStringValue('casino.offer');
    this.copy.getResourceStringValue('casino.signup');
    this.modal.getModal().subscribe(value => {
      // Split string into params.
      setTimeout(() => {
        this.modalToggle = value.split(',');
        if (this.modalToggle[0] === 'clear') {
          this.modals = [];
          this.render.removeClass(document.body, 'modal-open');
        } else {
          this.modalToggle[0] === 'open' ? this.modalOpen(this.modalToggle[1]) : this.modalClose(this.modalToggle[1]);
          if (this.modalToggle[1] === 'rmm') {
            this.modalUrl = this.modalToggle[2];
          }
          if (this.modalToggle[1] === 'openUrl') {
            this.modalUrl = this.modalToggle[2];
          }
          if (this.modalToggle[1] === 'game-overlay') {
            this.modalStyles = {};
          }
          this.modalGameId = this.modalToggle[2] || 0;
        }
      }, 0);
    });
  }

  ngOnInit() {
    // Listen to modal service to toggle open / close


    this.modal.getContent().subscribe(value => {
      this.modalContent = value;
    });
  }
  ngOnDestroy() {
    //this.modalClear();
  }

  modalOpen(id: string) {
    this.modals[id] = true;
    this.render.addClass(document.body, 'modal-open');
    this.visible = false;
  }

  modalClose(id: string) {
    this.modals[id] = false;
    console.log(id);
    this.render.removeClass(document.body, 'modal-open');
  }

  modalClear() {
    this.modal.clearAll();
  }

}
