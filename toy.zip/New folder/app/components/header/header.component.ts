import { Component, OnInit, OnDestroy } from '@angular/core';
import { GameService } from '../../services/game.service';
import { AuthService } from '../../services/auth.service';
import { UserService } from '../../services/user.service';
import { ContentService } from '../../services/content.service';
import { Subscription } from 'rxjs/Subscription';
import { ModalService } from '../../services/modal.service';
import { Observable } from 'rxjs/Observable';
import { AccountService } from '../../services/account.service';
import 'rxjs/add/observable/timer';
import { RmmService } from '../../services/rmm.service';
import { element } from 'protractor';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnDestroy {
  host: any = (<any>window).global.request.host;
  error = '';
  showNav = true;
  resourceStrings: any = {};
  gameId: any;
  motdId: any;
  userbalance: any = '0';
  gameCat: any = [];
  timer: Observable<number>;
  subscription: Subscription;
  isMobile: boolean;
  tempActiveIndex: any;
  activeLinkIndex: number;
  isChecked: any[];
  rmmList = [];
  currentQueue = 0;
  navListArr: any;
  navShowArr = [];
  count = 0;
  constructor(
    private game: GameService,
    public auth: AuthService,
    private user: UserService,
    private copy: ContentService,
    private modal: ModalService,
    private account: AccountService,
    private rmm: RmmService) {
    this.isChecked = [];
    this.navListArr = [];
    this.isMobile = (<any>window).global.request.device.isMobile;
    if (this.isMobile && !this.auth.isAuthenticated) {
      this.showNav = false;
      this.navListArr = (<any>window).global.sitemap.filter((value) => {
        this.isChecked.push(false);
        return value.TN;
      });
    }

    this.auth.toggleAuth.subscribe(res => {
      if (res !== undefined && this.count === 0) {
        this.count = 1;
        this.account.getAccountInformation().subscribe(data => {
          console.log(data);
          for (const key in data) {
            if (this.account.account.hasOwnProperty(key)) {
              this.account.setAcctProperty(key, data[key].trim());
            } else if (key === 'AddressLine1') {
              this.account.setAcctProperty('Address1', data[key].trim());
            } else if (key === 'MobilePhone') {
              this.account.setAcctProperty('PhoneMobile', data[key].trim());
            } else if (key === 'BirthDate') {
              this.account.setAcctProperty('DateOfBirth', data[key].trim());
            }
          }
          console.log(this.account.account);
        });
      } else if (this.count === 1 && res === undefined) {
        this.count = 0;
      }

    });


    this.copy.resourceStringPackEmit.subscribe(res => {
      this.resourceStrings = res;
    }
    );
    this.copy.getResourceStringValue('casino.header');
    this.game.gameCats.subscribe(data => {
      this.gameCat = this.game.getStoredGameCats();
    },
      err => { }
    );
    this.getGameCategories();
    window.addEventListener('message', (event) => {
      {
        if (event.origin === 'https://rmm2.dmgamingsystems.com') {
          let data = event.data;
          if (typeof data === 'string') {
            data = JSON.parse(data);
            switch (data.method) {
              case 'launchgame':
                this.launchGameById(data.params);
                break;
              case 'closermm':
                this.modal.close('rmm');
                break;
              default:
                console.log('Unknown method ', data.method);
                break;
            }
          }
        }
      }
    }, false);


  }
  ngOnInit() {
    // this.getRMMCount();
    this.getUserBalance();
  }

  getCount() {
    this.account.getInboxCount()
      .subscribe(
      data => {
        this.user.setUser('msgCount', data[0].EmailCount);
      },
      err => { }
      );
  }

  logOut() {
    this.auth.logOut();
  }

  modalOpen(modal) {
    this.modal.open(modal, '');
    if (this.isMobile) {
      this.showNav = false;
    }
  }

  getUserBalance() {
    this.userbalance = this.user.getUser().balance;
  }

  toggleActiveNav(index) {
    if (this.tempActiveIndex === index && this.activeLinkIndex !== -1) {
      this.isChecked = [];
      this.activeLinkIndex = -1;
    } else {
      this.activeLinkIndex = index;
      this.isChecked = [];
      this.isChecked[index] = true;
    }
    this.tempActiveIndex = index;
  }

  getGameCategories() {
    this.game.getGameCat().subscribe(
      data => {
        this.gameCat = data;
      },
      err => { console.log(err); }
    );
  }

  getRMMCount() {
    this.timer = Observable.timer(0, 10000);
    this.subscription = this.timer.subscribe(t => {
      if (this.user.getUser().AuthToken.length > 0) {
        this.rmm.getRmmCnt(this.user.getUser().CasinoCode, this.user.getUser().XmanSessionToken)
          .subscribe(res => {
            if (res.Pkt.Response.NumMessages.NodeAttributes.count !== '0') {
              this.getRMM(this.user.getUser().CasinoCode, this.user.getUser().XmanSessionToken);
            }
          });
      }
    });
  }

  getRMM(casinoCode, xSession) {
    this.rmm.getRmmContent(casinoCode, xSession)
      .subscribe(res => {
        if (res.Pkt.Response.Error) {
          this.error = res.Pkt.Response.Error.NodeAttributes.text;
        }
        if (res['Pkt'].Response.Message !== undefined) {
          if (res['Pkt'].Response.Message.NodeAttributes.messageIdentifier !== undefined) {
            const modal = this.rmm.launchRMM(res.Pkt.Id.NodeAttributes.sid, res.Pkt.Response.Message.NodeAttributes.messageIdentifier);
            this.rmmList.push(modal);
            console.log('RMM List', this.rmmList);
            this.rmmQueueHandler(this.rmmList);
          }
        }

        return res;
      });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  launchGameById(event) {
    this.game.getGameObjFromLBId(event).subscribe();
  }
  getMotdId(event) {
    this.motdId = event;
  }
  rmmQueueHandler(rmmList) {
    if (rmmList[this.currentQueue] !== undefined) {
      this.modal.open('rmm', rmmList[this.currentQueue]);
      this.currentQueue++;
    }
  }
}
