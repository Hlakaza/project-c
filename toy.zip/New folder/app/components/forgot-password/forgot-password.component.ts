import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
  passSwitch: boolean = true;
  loading: boolean;
  show: boolean;
  forgotPasswordGroup: FormGroup;
  forgotPasswordCode: FormGroup;
  forgotPasswordNewPassword: FormGroup;
  @Input() forgotSwitch = 1;

  constructor() {
    this.forgotPasswordGroup = new FormGroup({
      fpUsername: new FormControl(null, [Validators.required]),
    });
    this.forgotPasswordCode = new FormGroup({
      fpCode: new FormControl(null, [Validators.required]),
    });
    this.forgotPasswordNewPassword = new FormGroup({
      fpNewPassword: new FormControl(null, [Validators.required]),
    });
  }

  ngOnInit() {
    this.switchPanel(this.forgotSwitch);
    this.loading = false;
  }

  switchPanel(data) {
    this.forgotSwitch = data;
  }

  togglePassView() {
    this.passSwitch = !this.passSwitch;
  }


}
