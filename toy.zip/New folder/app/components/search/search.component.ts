import { Component, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/debounceTime';
import { GameService } from '../../services/game.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements AfterViewInit {
  model: string;
  games: any;
  loading: boolean;
  modelChanged: Subject<string> = new Subject<string>();
  @ViewChild('searchField') firstNameElement: ElementRef;

  constructor(private game: GameService) {
    this.games = [];
    this.loading = false;

    this.modelChanged
      .debounceTime(300) // wait 300ms after the last event before emitting last event
      .subscribe(model => {
        this.model = model;

        if (this.model.length) {
          this.game.getGames(0, 10, this.model, null)
            .subscribe(res => {
              this.games = res;
              this.loading = false;
            }, err => {
              console.log(err);
              this.loading = false;
            });
        } else {
          this.games = [];
          this.loading = false;
        }

      });
  }

  ngAfterViewInit() {
    this.firstNameElement.nativeElement.focus();
  }

  changed(text: string) {
    this.loading = true;
    this.modelChanged.next(text);
  }

  clear() {
    this.modelChanged.next('');
  }

}
