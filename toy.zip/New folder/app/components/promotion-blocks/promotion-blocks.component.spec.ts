import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PromotionBlocksComponent } from './promotion-blocks.component';

describe('PromotionBlocksComponent', () => {
  let component: PromotionBlocksComponent;
  let fixture: ComponentFixture<PromotionBlocksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PromotionBlocksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PromotionBlocksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
