import { Component, OnInit, SecurityContext } from '@angular/core';
import { ContentService } from '../../services/content.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Router, NavigationEnd } from '@angular/router';
import { RouteDataService } from '../../services/route-data.service';

@Component({
  selector: 'app-promotion-blocks',
  templateUrl: './promotion-blocks.component.html',
  styleUrls: ['./promotion-blocks.component.scss']
})
export class PromotionBlocksComponent implements OnInit {
  sitemap: any = (<any>window).global.sitemap;
  promotionBlockGuid: any;
  promotionBlockContent: any;
  isHome = false;
  copy = [];
  copyObj = [];
  constructor(
    private routeData: RouteDataService,
    private contentSrvc: ContentService,
    private sanitizer: DomSanitizer,
  ) {
    this.routeData.urlData.subscribe(urlData => {
      urlData.length === 0 ? this.isHome = true : this.isHome = false;
    });
    this.routeData.promotionBlocks.subscribe(promoData => {
      this.promotionBlockGuid = promoData;
      this.getPromotionBlocksContent();
    });
  }

  ngOnInit() {

  }

  getPromotionBlocksContent() {
    if (this.contentSrvc.getContentByGuid(this.promotionBlockGuid) !== undefined) {
      this.contentSrvc.getContentByGuid(this.promotionBlockGuid).subscribe(res => {
      
        if (res !== undefined) {
          if (res['WP'] !== null) {
            for (let i = 0; i < res['Count']; i++) {

              res['WP'].filter((value) => {
                if (value.WPName === res['WPN'][i]) {
                  this.copyObj.push(
                    {
                      link: value.WPC.match(/routerlink=".*"/g)[0].replace(/routerlink="/g, '').replace(/"/g, ''),
                      title: value.WPC.match(/(?=>).*/g)[0].replace(/<\/a>/g, '').replace(/>/, '')
                    });

                  // this.copy.push(value.WPC);
                }
              });
            }
          }
        }
      });
    }
  }
}
