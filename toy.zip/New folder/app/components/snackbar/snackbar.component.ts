import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { CookieBarService } from '../../services/cookie-bar.service';
import { FlashDetectService } from '../../services/flash-detect.service';

@Component({
  selector: 'app-snackbar',
  templateUrl: './snackbar.component.html',
  styleUrls: ['./snackbar.component.scss']
})
export class SnackbarComponent implements OnInit {
  showCookieBar: boolean;
  showFlashBar: boolean;
  constructor(
    private cookieBar: CookieBarService,
    private cookieService: CookieService,
    private flash: FlashDetectService
  ) { }

  ngOnInit() {
    this.showCookieBar = this.cookieBar.isCookieHidden();
    this.showFlashBar = this.flash.isFlashEnabled();
  }

  close() {
    this.showCookieBar = false;
  }

}
