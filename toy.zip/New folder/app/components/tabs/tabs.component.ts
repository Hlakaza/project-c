import { Component, ContentChildren, QueryList, AfterContentInit, Input } from '@angular/core';
import { TabComponent } from './tab.component';
import { AuthService } from '../../services/auth.service';
import { ModalService } from '../../services/modal.service';
import { UserService } from '../../services/user.service';

import { from } from 'rxjs/observable/from';
@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html'
})
export class TabsComponent implements AfterContentInit {
  constructor(
    private auth: AuthService,
    private modal: ModalService,
    private user: UserService
  ) { }
  activeTabs: any[];
  isMobile: boolean;

  @Input() vertical = false;
  @Input() isTabSub = false;
  @Input() stepper = false;
  @Input() selectedIndex = 0;
  @ContentChildren(TabComponent) tabs: QueryList<TabComponent>;

  // contentChildren are set
  ngAfterContentInit() {
    // Make sure there are tabs
    this.isMobile = window.innerWidth < 640 ? true : false;

    if (this.tabs.length && !this.isTabSub) {
      this.selectTab(this.selectedIndex);
    } else if (!this.isMobile) {
      this.selectTab(this.selectedIndex);
    }

  }

  selectTab(index) {

    if (!this.tabs.toArray()[index].disabled) {

      this.tabs.toArray().forEach(value => value.active = false);

      this.tabs.toArray()[index].active = true;

      if (this.tabs.toArray()[index].isSub ) {
        this.isTabSub = false;
      }

      if ((this.tabs.toArray()[index].trigger === 'logout') && (this.tabs.toArray()[index].active)) {
        this.auth.logOut();
        this.modal.clearAll();
      }
    }
  }

}
