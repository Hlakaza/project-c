import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-tab',
    template: `
    <div *ngIf="active" class="tab-content">
      <button type="button" class="back-arrow pull-left" (click)="active=false" data-dismiss="modal" aria-label="back">
        <span aria-hidden="true">&lt;</span>
      </button>
      <ng-content></ng-content>
    </div>
  `
})
export class TabComponent {
    @Input() title: string;
    @Input() trigger: string;
    @Input() svg: string;
    @Input() disabled: boolean;
    @Input() isSub = false;
    @Input() active = false;
}
