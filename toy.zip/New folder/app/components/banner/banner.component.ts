import { Component, OnInit, SecurityContext } from '@angular/core';
import { Router, ResolveEnd, NavigationEnd, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { SafePipe } from '../../pipes/safe.pipe';
import { ContentService } from '../../services/content.service';
import { CookieService } from 'ngx-cookie-service';
import { DomSanitizer } from '@angular/platform-browser';
import { RouteDataService } from '../../services/route-data.service';

@Component({
  selector: 'app-banner',
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.component.scss']
})

export class BannerComponent implements OnInit {
  slides: any;
  isHome = false;
  cookieValue = '';
  secondaryOfferGuid = [];
  sitemap: any = (<any>window).global.sitemap;
  match: any;
  offerContent: any;
  constructor(
    public auth: AuthService,
    private sanitizer: DomSanitizer,
    private cookieService: CookieService,
    private contentSrvc: ContentService,
    private routeData: RouteDataService
  ) {
    this.slides = [];
    this.routeData.urlData.subscribe(urlData => {
      urlData.length === 0 ? this.isHome = true : this.isHome = false;
    });
    this.cookieValue = this.cookieService.get('BTAGCOOKIE');
  }

  ngOnInit() {
    this.routeData.secondaryBanner.subscribe(bannerGuid => {
      this.secondaryOfferGuid.push(bannerGuid);
      this.getSecondaryOffersCopy();
    });
  }

  getSecondaryOffersCopy() {
    const isSEO = this.cookieValue.match(/se-go/g) ? true : false;
    this.contentSrvc.getContentByGuid(this.secondaryOfferGuid)
      .subscribe(res => {
        if (res !== undefined) {
          if (!isSEO) {
            this.match = res['WP'].filter(val => !val.WPName.match(/seo/g))[0];
          } else if (isSEO) {
            this.match = res['WP'].filter(val => val.WPName.match(/seo/g))[0];
          }
          this.offerContent = this.match.WPC;
        }
      });
  }
}


