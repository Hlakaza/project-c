import { Component, OnInit, ElementRef, HostListener, Input, SecurityContext, OnChanges } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/observable/timer';
import { SafePipe } from '../../pipes/safe.pipe';
import { Element } from '@angular/compiler';
import { MotdService } from '../../services/motd.service';
import { DomSanitizer } from '@angular/platform-browser';
import { ModalService } from '../../services/modal.service';
import { UserService } from '../../services/user.service';
import { ContentService } from '../../services/content.service';
import { CookieService } from 'ngx-cookie-service';
import { GameService } from '../../services/game.service';

@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.scss']
})
export class SliderComponent implements OnInit {
  slides: any;
  navTabs: any;
  slideIndex = 0;
  slideDirection = '';
  showLeftArrow: boolean;
  showRightArrow: boolean;
  ticks = 0;
  timer: Observable<number>;
  subscription: Subscription;
  subject = new Subject();
  moreInfoContent: any;
  gameId: any;
  sitemap: any = (<any>window).global.sitemap;
  host: any = (<any>window).global.request.host;
  copy: any = [];
  isMobile: boolean;
  offerPGuidArr = [];
  cookieValue = '';
  kenticoSlider: any = [];
  match: any;
  loading = true;
  count = 0;
  resourceStrings = {};
  constructor(
    public auth: AuthService,
    private motdService: MotdService,
    private modal: ModalService,
    private user: UserService,
    private sanitizer: DomSanitizer,
    private cookieService: CookieService,
    private copySrvc: ContentService,
    private game: GameService
  ) {

    this.copySrvc.resourceStringPackEmit.subscribe(res => {
      this.resourceStrings = res;
    }
    );
    this.copySrvc.getResourceStringValue('casino.header');

    this.slides = [];
    this.navTabs = [];
    this.showRightArrow = true;
    this.timer = Observable.timer(2000, 4000);
    this.subscription = this.timer.subscribe(t => {
      this.carouselTimer(t);
    });
    this.cookieValue = this.cookieService.get('BTAGCOOKIE');

    this.auth.toggleAuth.subscribe(res => {
      if (res !== undefined && this.count === 0) {
        this.slides = [];
        this.getImages(this.user.getUser().BrandCode, this.user.getUser().CultureCode);
        this.count = 1;
      } else if (this.count === 1 && res === undefined) {
        this.slides = [];
        this.offerPGuidArr = [];
        this.sitemap.map(value => {
          if (value.A === 'Offer-Banner-Slider') {
            value.CH.map(item => {
              this.offerPGuidArr.push(item.PG);
            });
          }
        });
        this.getOffersCopy();
        this.count = 0;
      }
    });

    this.sitemap.map(value => {
      if (value.A === 'Offer-Banner-Slider') {
        value.CH.map(item => {
          this.offerPGuidArr.push(item.PG);
        });
      }
    });
    this.getOffersCopy();
  }

  ngOnInit() {
    // this.moreInfoContent.getMotdInformation().subscribe( res => res );
    this.isMobile = (<any>window).global.request.device.isMobile;
  }

  getOffersCopy() {
    const isSEO = this.cookieValue.match(/se-go/g) ? true : false;

    for (const slide of this.offerPGuidArr) {
      this.copySrvc.getContentByGuid(slide)
        .subscribe(res => {
          if (res !== undefined) {
            if (!isSEO) {
              this.match = res['WP'].filter(val => !val.WPName.match(/seo/g));
            } else if (isSEO) {
              this.match = res['WP'].filter(val => val.WPName.match(/seo/g));
            }
            const kenticoContentObject = {
              title: this.match[0].WPC,
              content: this.match[1].WPC
            };
            this.slides.push(kenticoContentObject);
          }
        });
    }
  }

  launchGameById(event) {
    this.game.getGameObjFromLBId(event).subscribe();
  }

  getMoreInfo(event) {
    this.moreInfoContent = event;
  }

  carouselTimer(tick) {
    if (this.slideIndex < this.slides.length - 1) {
      this.slideIndex++;
    } else {
      this.slideIndex = 0;
    }
  }

  // Get MOTDS from API
  getImages(brandCode, cultureCode) {
    this.motdService.getMotds()
      .subscribe(data => {
        data['Motds'].map(item => {
          const slideInfoItem = {
            AbsolutePath: item.AbsolutePath,
            ContentPath: item.ContentPath,
            HtmlFilePath: item.HtmlFilePath,
            MotdId: item.MotdId,
            PromotionId: item.PromotionId,
            Title: item.Title
          };
          console.log(item);
          this.slides.push(slideInfoItem);
          this.loading = false;
        });
      }, err => {
        console.error('Slider', err);
      });
  }

  // Go to next slide
  next(slideIndex) {
    if (slideIndex < this.slides.length - 1) {
      this.slideIndex++;
      this.slideDirection = 'right';
    } else {
      this.slideIndex = 0;
    }
    console.log(slideIndex);
  }

  // Go to previous slide
  prev(slideIndex) {
    if (slideIndex > 0) {
      this.slideIndex--;
      this.slideDirection = 'left';
    } else {
      this.slideIndex = this.slides.length - 1;
    }
  }

  // Go to specific slide
  goToSlide(slideIndex) {
    this.slideIndex = slideIndex;
  }

  pause(pauseState) {
    if (pauseState) {
      // stop timer
      this.subscription.unsubscribe();
    } else {
      // start timer
      this.subscription = this.timer.subscribe(t => {
        this.carouselTimer(t);
      });
    }
  }
}
