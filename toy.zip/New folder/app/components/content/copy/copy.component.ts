import { Component, Input, SecurityContext, AfterViewInit } from '@angular/core';
import { Router, ResolveEnd, NavigationEnd, ActivatedRoute } from '@angular/router';
import { ContentService } from '../../../services/content.service';
import { Subscription } from 'rxjs/Subscription';
import { DomSanitizer } from '@angular/platform-browser';
import { XmlToJsonPipe } from '../../../pipes/xml-to-json.pipe';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';
import { RouteDataService } from '../../../services/route-data.service';
@Component({
  selector: 'app-copy',
  templateUrl: './copy.component.html',
  styleUrls: ['./copy.component.scss']
})
export class CopyComponent implements AfterViewInit {
  host: any = (<any>window).global.request.host;
  waiting = true;
  columnStyles: string;
  copy: any = [];
  isHome = false;
  gamePage = false;
  title = '';
  urlArr = [];
  constructor(private copySrvc: ContentService, private sanitizer: DomSanitizer, private routeData: RouteDataService) {
    this.routeData.urlData.subscribe(urlData => {
      if (urlData.length === 0) {
        this.isHome = true;
      } else {
        this.isHome = false;
        if (urlData[0].path.indexOf('Giochi') !== -1) {
          this.gamePage = true;
        } else {
          this.gamePage = false;
        }
      }

      this.urlArr = [];
      urlData.map((value, index) => {
        const obj = {};
        obj['name'] = value.path;
        if (this.urlArr[index - 1] !== undefined) {
          obj['path'] = this.urlArr[index - 1].path + '/' + value.path;
        } else {
          obj['path'] = value.path;
        }
        this.urlArr.push(obj);
      });

    });
    this.routeData.copyData.subscribe(copyDataRes => {
      this.title = '';
      this.copy = [];
      this.waiting = true;
      this.copySrvc.getContentByGuid(copyDataRes.value).subscribe(res => {
        for (let i = 0; i < res['Count']; i++) {
          if (res['WPN'][i].toLowerCase().indexOf('head') !== -1) {
            res['WP'].filter((value) => {
              if (value.WPName === res['WPN'][i]) {
                this.title = value.WPC;
              }
            });
          } else if (res['WPN'][i].toLowerCase().indexOf('edit') !== -1) {
          } else {
            res['WP'].filter((value) => {
              if (value.WPName === res['WPN'][i]) {
                this.copy.push(value.WPC.replace(/~/g, ''));
              }
            });
          }
        }
        switch (this.copy.length) {
          case 1:
            this.columnStyles = 'col-twelve grid';
            break;
          case 2:
            this.columnStyles = 'col-six grid';
            break;
          case 3:
            this.columnStyles = 'col-four grid';
            break;
          default:
            this.columnStyles = 'col-twelve grid';
            break;
        }
        this.waiting = false;
      });
    });


  }

  ngAfterViewInit() {

  }
}

