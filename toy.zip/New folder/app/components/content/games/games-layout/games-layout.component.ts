import { Component, Input, OnInit } from '@angular/core';
import { GameService } from '../../../../services/game.service';
import { AfterViewInit } from '@angular/core/src/metadata/lifecycle_hooks';
import { SimpleChange } from '@angular/core/src/change_detection/change_detection_util';
import { RouteDataService } from '../../../../services/route-data.service';

@Component({
    selector: 'app-games-layout',
    templateUrl: './games-layout.component.html',
    styleUrls: ['./games-layout.component.scss'],
})
export class GamesLayoutComponent implements OnInit {
    @Input() gameInfo: any;
    @Input() full: any;
    @Input('filter')
    set filter(value) {
        this._filter = value;
        this.filterGames(value);
    }
    get filter(): string {
        return this._filter;
    }
    sliceLimit = 4;
    _filter: string;
    currentFilter: any = '';
    currentArrVisible = false;
    currentArr = [];
    games = [];
    dummyArray = [];
    dummyFullArray = [];
    featCat = false;
    isMobile = (<any>window).global.request.device.isMobile;
    constructor(private game: GameService) {
        for (let i = 0; i < 30; i++) {
            this.dummyFullArray.push(i);
        }
        for (let i = 0; i < 4; i++) {
            this.dummyArray.push(i);
        }
    }
    fetchGames(full) {
        let limit;
        if (full) {
            limit = 30;
        } else {
            limit = 10;
        }
        if (this.gameInfo.GCId !== 'blank') {
            if (this.game.getGamesRepo(this.gameInfo.GCId) === undefined) {
                this.game.getGames(0, limit, null, this.gameInfo.GCId).subscribe(res => {
                    this.currentArrVisible = true;
                    this.game.setGamesRepo(this.gameInfo.GCId, res);
                    (<any>res).map((value, index) => {
                        if (index <= 5) {
                            this.game.getGameLaunchURL(value.Gid, true).subscribe();
                        }
                    });
                    this.games = this.game.getGamesRepo(this.gameInfo.GCId);
                });
            } else {
                this.games = this.game.getGamesRepo(this.gameInfo.GCId);
            }
        }
    }

    newGames(event) {
        this.games = this.game.getGamesRepo(this.gameInfo.GCId).concat(event);
        this.game.setGamesRepo(this.gameInfo.GCId, this.games);
        if (this.currentFilter !== '') {
            this.filterGames(this.currentFilter);
        }
    }
    filterGames(filter) {
        if (filter !== '') {
            this.games = this.game.getGamesRepo(this.gameInfo.GCId).filter((game) => {
                if (game.hasOwnProperty(filter)) {
                    if (filter === 'Heat') {
                        if (game.Heat === 2) {
                            return game;
                        }
                    }
                    if (filter === 'IsN') {
                        if (game.IsN) {
                            return game;
                        }
                    }

                    return null;
                }
            });
        } else {
            this.games = this.game.getGamesRepo(this.gameInfo.GCId);
        }

    }
    ngOnInit() {
        if (this.full) {
            this.games = (<any>this.dummyFullArray);

        } else {
            if (this.gameInfo.GCId === 'cb3a1eb4-2c9c-4c23-80ce-500a566b1222') {
                if (this.isMobile) {
                    this.sliceLimit = 6;
                } else {
                    this.sliceLimit = 5;
                }
            } else {
                this.sliceLimit = 4;
            }
            this.games = (<any>this.dummyArray);
        }
        this.fetchGames(this.full);
    }
}
