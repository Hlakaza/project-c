import { Component, EventEmitter, Output } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, ActivatedRoute } from '@angular/router';
import { GameService } from '../../../services/game.service';
import { UserService } from '../../../services/user.service';
import { AuthService } from '../../../services/auth.service';
import { RouteDataService } from '../../../services/route-data.service';


@Component({
    selector: 'app-games',
    templateUrl: './games.component.html',
    styleUrls: ['./games.component.scss']
})
export class GamesComponent {
    filter = '';
    full = false;
    currentCat = [];
    gameCat = [];
    gameCatVisible = false;
    show: boolean;
    path: any = '';
    isMobile = (<any>window).global.request.device.isMobile;
    constructor(
        private routeData: RouteDataService,
        private game: GameService,
        private user: UserService,
        private auth: AuthService) {
        this.show = false;
        for (let i = 0; i < 3; i++) {
            this.gameCat.push(
                {
                    'GCId': 'blank',
                    'PCId': 'blank',
                    'GCN': ''
                });
        }
        this.routeData.gameData.subscribe(data => {
            if (data.showGames) {
                this.full = data.full;
                if (data.full) {
                    if (data.path.length === 0) {
                    } else {
                        this.path = data.path;
                        this.gameRequest(data.path);
                    }
                } else {
                    this.path = '';
                    this.gameRequest();
                }
            }
        });
    }

    setFilter(data) {
        this.filter = data;
    }
    gameRequest(path?) {
        if (this.game.getStoredGameCats().length === 0) {
            this.game.getGameCat().subscribe(res => {
                this.gameCat = (<any>res);
                this.gameCatVisible = true;
                if (path !== '') {
                    this.gameCat.filter((value) => {
                        let checkVal = '';
                        checkVal = value.NP.replace('/Giochi/', '');
                        if (checkVal.indexOf(path) !== -1) {
                            this.currentCat = [value];
                        }
                    });
                }
            });
        } else {
            if (path !== '') {
                this.gameCat = this.game.getStoredGameCats();
                this.gameCat.filter((value) => {
                    let checkVal = '';
                    checkVal = value.NP.replace('/Giochi/', '');
                    if (checkVal.indexOf(path) !== -1) {
                        this.currentCat = [value];
                    }
                });
            } else {
                this.gameCat = this.game.getStoredGameCats();
            }

        }
    }



}

