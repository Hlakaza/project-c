import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { GameService } from '../../../../services/game.service';
import { ModalService } from '../../../../services/modal.service';
import { AuthService } from '../../../../services/auth.service';

@Component({
  selector: 'app-game-overlay',
  templateUrl: './game-overlay.component.html',
  styleUrls: ['./game-overlay.component.scss']
})
export class GameOverlayComponent implements OnInit {
  @Output() backgroundImage: any = new EventEmitter<any>();
  gamesOverlay = false;
  iFrameWidth = '100%';
  iFrameHeight = '700px';
  iFrameURL = '';
  iFrameLoading = true;
  @Input() gameId: any;


  constructor(private game: GameService, private modal: ModalService, private auth: AuthService) {
    this.game.gameLaunchObj.subscribe(res => {
      this.iFrameLoading = false;
      const biURL = 'https://cdn1.dmgamingsystems.com' + res['BI'];
      this.backgroundImage.emit({ 'background-image': `url(${biURL})` });
      this.iFrameURL = res['GLP'];
    });
  }
  ngOnInit() {
    if (this.game.getGameLaunchRepo(this.gameId, this.auth.isAuthenticated) !== undefined) {
      this.iFrameLoading = false;
      const biURL = 'https://cdn1.dmgamingsystems.com' + this.game.getGameLaunchRepo(this.gameId, this.auth.isAuthenticated)['BI'];
      this.backgroundImage.emit({ 'background-image': `url(${biURL})` });
      this.iFrameURL = this.game.getGameLaunchRepo(this.gameId, this.auth.isAuthenticated)['GLP'];
    }
  }

}
