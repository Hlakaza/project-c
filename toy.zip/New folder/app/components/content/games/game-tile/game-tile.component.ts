import { Component, OnInit, Input } from '@angular/core';
import { GameService } from '../../../../services/game.service';
import { ModalService } from '../../../../services/modal.service';
import { AuthService } from '../../../../services/auth.service';

@Component({
  selector: 'app-game-tile',
  templateUrl: './game-tile.component.html',
  styleUrls: ['./game-tile.component.scss'],

})
export class GameTileComponent implements OnInit {
  @Input() gameInfo: any;
  hover = false;
  tileImage: string;
  isNew: string;
  heat: number;
  gameId: string;
  gameName: string;
  isMobile: boolean;
  featured = false;
  LPId: any;
  GP: any;
  BackgroundImage: any;
  isAuth = false;
  constructor(private game: GameService, private modal: ModalService, public auth: AuthService) { }

  mouseEnter() {
    this.hover = true;
  }
  mouseExit() {
    this.hover = false;
  }
  ngOnInit() {
    if (this.gameInfo !== undefined && typeof this.gameInfo !== 'number') {
      this.tileImage = 'https://cdn1.dmgamingsystems.com' + this.gameInfo.TI;
      this.isNew = this.gameInfo.IsN;
      this.heat = this.gameInfo.Heat;
      this.gameId = this.gameInfo.Gid;
      this.gameName = this.gameInfo.GN;
      this.isMobile = this.gameInfo.IsOP;
    }
  }
  launchGame(value) {
    if (value !== undefined) {
      this.modal.open('game-overlay', value);
      this.modal.toggleModal.subscribe(res => { });
      this.game.getGameLaunchURL(value, false).subscribe();
    }

  }

}

