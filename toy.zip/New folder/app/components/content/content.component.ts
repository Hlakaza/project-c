import { Component, OnInit } from '@angular/core';
import { ContentService } from './../../services/content.service';
import { Router } from '@angular/router';
import { RouteDataService } from '../../services/route-data.service';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.scss']
})
export class ContentComponent {

  loading: boolean;
  error: string;
  bodyConent: any;
  count = 0;
  showGames = true;
  constructor(
    private content: ContentService,
    private routeData: RouteDataService
  ) {
    this.routeData.gameData.subscribe(data => {
      this.showGames = data.showGames;
    });
  }

}
