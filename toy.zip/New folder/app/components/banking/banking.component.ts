import {
  Component,
  AfterViewInit,
  ElementRef,
  ViewChild,
  Renderer2
} from '@angular/core';
import { BankingService } from '../../services/banking.service';
import { GlobalInfoService } from '../../services/global-info.service';
import { UserService } from '../../services/user.service';
import { AccountService } from '../../services/account.service';

@Component({
  selector: 'app-banking',
  templateUrl: './banking.component.html',
  styleUrls: ['./banking.component.scss']
})
export class BankingComponent implements AfterViewInit {
  @ViewChild('bankingRef') bankingRef: ElementRef;
  banking: any;
  bankingIFrame = '';
  motdID = 'Default-Banking-Flash';
  isMobile = (<any>window).global.request.device.isMobile;
  constructor(
    private bankingService: BankingService,
    private renderer: Renderer2,
    private globalInfo: GlobalInfoService,
    private user: UserService
  ) {
    if (this.globalInfo.metaData.BrandExternalApplications.length > 0) {
      this.globalInfo.metaData.BrandExternalApplications.filter(value => {
        if (
          value.ExternalApplicationTypeId ===
          'd80af463-8e1e-4e33-b100-b29de0affd5f'
        ) {
          this.bankingIFrame = value['ExternalApplicationUrl'];
          this.bankingIFrame = this.bankingIFrame
            .replace('${UserName}', this.user.getUser().LoginName)
            .replace(
              '${RaptorSessionToken}',
              this.user.getUser().RaptorSessionToken
            )
            .replace(
              '${ReturnUrl}',
              encodeURIComponent('http://www.royalvegascasino.com')
            )
            .replace('${MOTD}', this.motdID);
          //window.open(this.bankingIFrame, '_blank', 'width=1024, height=768');
        }
      });
    } else {
      this.globalInfo.brandExtensions.subscribe(res => {
        res.filter(value => {
          if (
            value.ExternalApplicationTypeId ===
            'd80af463-8e1e-4e33-b100-b29de0affd5f'
          ) {
            this.bankingIFrame = value['ExternalApplicationUrl'];
            this.bankingIFrame = this.bankingIFrame
              .replace('${UserName}', this.user.getUser().LoginName)
              .replace(
                '${RaptorSessionToken}',
                this.user.getUser().RaptorSessionToken
              )
              .replace(
                '${ReturnUrl}',
                encodeURIComponent('http://www.royalvegascasino.com')
              )
              .replace('${MOTD}', this.motdID);
            //window.open(this.bankingIFrame, '_blank', 'width=1024, height=768');
          }
        });
      });
    }
  }

  loadBanking() {
    this.bankingService.getBanking().subscribe(
      data => {
        this.banking = data;
        console.log(data);

        const c = this.renderer.createElement('script');
        c.src = '../javascript/jQuery.tmpl.js';
        const d = this.renderer.createElement('script');
        d.src = '../javascript/mgs.formsservice.min.js';
        const e = this.renderer.createElement('script');
        e.src = '../javascript/spin.js';
        const f = this.renderer.createElement('script');
        f.src = '../javascript/_MgsMobileBanking.js';
        this.renderer.appendChild(this.bankingRef.nativeElement, c);
        this.renderer.appendChild(this.bankingRef.nativeElement, d);
        this.renderer.appendChild(this.bankingRef.nativeElement, e);
        this.renderer.appendChild(this.bankingRef.nativeElement, f);
      },
      err => {
        console.log(err);
      }
    );
  }

  ngAfterViewInit() {
    if (this.isMobile && this.banking === undefined) {
      this.loadBanking();
      const a = this.renderer.createElement('script');
      a.src = 'https://code.jquery.com/jquery-1.10.2.min.js';

      this.renderer.appendChild(this.bankingRef.nativeElement, a);

      console.log('Fire');
    }
  }
}
