import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reg-step-end',
  templateUrl: './reg-step-end.component.html',
  styleUrls: ['./reg-step-end.component.scss']
})
export class RegStepEndComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
