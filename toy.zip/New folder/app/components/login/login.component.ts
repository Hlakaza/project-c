import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { ModalService } from '../../services/modal.service';
import { UserService } from '../../services/user.service';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';
import { ContentService } from '../../services/content.service';
import { AccountService } from '../../services/account.service';
import 'rxjs/add/operator/timeout';
import 'rxjs/add/operator/takeWhile';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loading: boolean;
  error: string;
  timer: Observable<number>;
  subscription: Subscription;
  host: any = (<any>window).global.request.host;
  resourceStrings: any = {};
  constructor(
    private auth: AuthService,
    private user: UserService,
    private modal: ModalService,
    private copy: ContentService,
    private account: AccountService) {

    this.copy.resourceStringPackEmit.subscribe(res => {
      this.resourceStrings = res;
    });
    this.copy.getResourceStringValue('casino.header');

  }

  // Dev UN 'Vdvr0002667871';
  // Dev P 'DevPWD';
  ngOnInit() {
    this.loading = false;
    this.loginForm = new FormGroup({
      username: new FormControl(null, Validators.required),
      password: new FormControl(null, Validators.required)
    });
  }

  login(username, password) {
    this.user.setUser('Password', password);
    this.user.setUser('LoginName', username);
    this.loginUser();
  }

  loginUser() {
    this.error = '';
    this.loading = true;
    const username = this.user.getUser().LoginName;
    const password = this.user.getUser().Password;
    const casinoCode = this.user.getUser().CasinoCode;
    const langCode = this.user.getUser().LangCode;

    this.auth.login(username, password)
      .timeout(600000)
      .subscribe(res => {

        if (res.Pkt.Response.Error) {
          this.error = res.Pkt.Response.Error.NodeAttributes.text;
          this.loading = false;
          return;
        }

        // this.user.setUser('AuthToken', 'Basic ' + btoa(`arnoldussrv:casino12`));
        this.user.setUser('AuthToken', 'Basic ' + btoa(username + ':' + password));
        this.user.setUser('XmanSessionToken', res.Pkt.Id.NodeAttributes.sessionid);
        this.user.setUser('RaptorSessionToken', res.Pkt.Response.SessionAuthentication.NodeAttributes.token);
        this.user.setUser('balance', res.Pkt.Response.PlayerInfo.NodeAttributes.Balance);

        const XmanSessionToken = this.user.getUser().XmanSessionToken;
        const RaptorSessionToken = this.user.getUser().RaptorSessionToken;
        const brandCode = this.user.getUser().BrandCode;
        const culturecode = this.user.getUser().CultureCode;

        // Hardcode username, password, brandCode and Culturecode for now.
        this.auth.loginMGS()
          .subscribe(
            token => {
              this.loading = false;
              this.user.setUser('AuthToken', 'Bearer ' + token);
              this.modal.clearAll();
              this.keepAlive();
            },
            err => {
              this.error = err.error.Errors;
              this.loading = false;
            });
      });
  }

  keepAlive() {
    const XmanSessionToken = this.user.getUser().XmanSessionToken;
    const casinoCode = this.user.getUser().CasinoCode;
    this.timer = Observable.timer(0, 120000);
    this.subscription = this.timer.subscribe(() => {
      this.auth.keepAlivePing(XmanSessionToken)
        .subscribe(res => {
          if (res.Pkt.Id.NodeAttributes.sessionid !== XmanSessionToken) {
            this.user.setUser('XmanSessionToken', res.Pkt.Id.NodeAttributes.sessionid);
            this.user.setUser('mgsUserID', res.Pkt.Response.SessionAuthentication.NodeAttributes.userId);
          }
        });
    });
  }

  getLocalResourceStrings(key) {
    this.copy.getResourceString(key).subscribe(res => {
      this.resourceStrings = res;      
    });
  }

  getCount() {

    this.account.getInboxCount()
      .subscribe(
        data => {
          this.user.setUser('msgCount', data[0].EmailCount);
        },
        err => {}
      );
  }

  getBalance() {

    const token = this.user.getUser().AuthToken;
    this.account.getBalance(token)
      .subscribe(
        data => {
          this.user.setUser('balance', data['CashBalance']);
        },
        err => {}
      );
  }
}
