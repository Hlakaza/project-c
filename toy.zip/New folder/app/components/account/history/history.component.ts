import { Component, OnInit } from '@angular/core';
import { ContentService } from '../../../services/content.service';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.scss']
})
export class HistoryComponent implements OnInit {
  resourceStrings: any = {};
  constructor(private copy: ContentService) {
    this.getLocalResourceStrings('casino.myaccount');
  }

  ngOnInit() {
  }
  getLocalResourceStrings(key) {
    this.copy.getResourceString(key).subscribe(res => {
      this.resourceStrings = res;
    });
  }
}
