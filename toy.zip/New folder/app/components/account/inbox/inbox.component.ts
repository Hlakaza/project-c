import { Component, OnInit, OnDestroy } from '@angular/core';
import { AccountService } from '../../../services/account.service';
import { UserService } from '../../../services/user.service';
import { ContentService } from '../../../services/content.service';

@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.scss']
})
export class InboxComponent implements OnInit, OnDestroy {
  emailMessages: any;
  messages: any;
  messageContent: string;
  resourceStrings: any = {};
  constructor(private account: AccountService, private user: UserService, private copy: ContentService) {
    this.getLocalResourceStrings('casino.myaccount');
  }

  ngOnInit() {
    this.messages = [];
    this.emailMessages = [];
    this.messageContent = '';

    this.loadInbox();
  }
  getLocalResourceStrings(key) {
    this.copy.getResourceString(key).subscribe(res => {
      this.resourceStrings = res;
    });
  }

  loadInbox() {
    this.account.getInbox()
      .subscribe(
      data => { this.emailMessages = data; },
      err => { console.log(err); }
      );
  }

  openMessage(id: string, content: string) {
    this.messages[id] = true;
    this.messageContent = content;
  }

  closeMessage() {
    this.messages = [];
    this.messageContent = '';
  }

  ngOnDestroy() {
    this.closeMessage();
  }

}
