import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../../services/account.service';
import { UserService } from '../../../services/user.service';
import { ContentService } from '../../../services/content.service';

@Component({
  selector: 'app-rewards',
  templateUrl: './rewards.component.html',
  styleUrls: ['./rewards.component.scss']
})
export class RewardsComponent implements OnInit {
  slideValue: number;
  loading: boolean;
  loyalty: any;
  error: any;
  resourceStrings: any = {};
  constructor(private account: AccountService, private user: UserService, private copy: ContentService) {
    this.getLocalResourceStrings('casino.myaccount');
  }

  ngOnInit() {
    this.error = {};
    this.loyalty = {};
    this.slideValue = 5;
    this.loadLoyalty();
  }

  loadLoyalty() {
    this.account.getLoyalty()
      .subscribe(
      data => { this.loyalty = data; },
      err => { console.log(err); }
      );
  }

  redeem(value) {
    this.account.loyaltyClaim(value)
      .subscribe(
      res => {
        console.log(res);
      },
      (err) => {
        console.log(err.error.Errors);

        this.error = {
          redeem: err.error.Errors
        };
      }
      );
  }


  getLocalResourceStrings(key) {
    this.copy.getResourceString(key).subscribe(res => {
      this.resourceStrings = res;
    });
  }
}
