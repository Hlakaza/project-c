import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../../services/account.service';
import { DocumentItem } from '../../../models/document.model';
import { ContentService } from '../../../services/content.service';

@Component({
  selector: 'app-document-verification',
  templateUrl: './document-verification.component.html',
  styleUrls: ['./document-verification.component.scss']
})
export class DocumentVerificationComponent implements OnInit {
  requested: any;
  brandCode: string;
  cultureCode: string;
  documents: any;
  error: any;
  statusId = {
    approved: '50a55dfc-ebf7-4e30-97a1-cc9a1bcc119d',
    requested: 'd066a8ee-cb9f-4791-b787-b336280477b8',
    pending: '2902e92f-c308-490e-8744-27d1f03527a0',
    rejected: 'f950e840-99e9-4cb4-b575-c0895bc10ae7'
  };
  resourceStrings: any = {};
  constructor(private account: AccountService, private copy: ContentService) {
    this.getLocalResourceStrings('casino.myaccount');
  }
  ngOnInit() {
    this.documents = [];
    this.error = {};

    this.getRequested(this.statusId.requested);
    this.getApproved(this.statusId.approved);
    this.getPending(this.statusId.pending);
    this.getRejected(this.statusId.rejected);
  }
  getLocalResourceStrings(key) {
    this.copy.getResourceString(key).subscribe(res => {
      this.resourceStrings = res;
    });
  }
  getRequested(status) {
    this.error = {};
    this.account.getDocuments(true, status)
      .subscribe(
      res => {
        this.documents['requested'] = res['Documents'].map(item => {
          return new DocumentItem(
            item.DocumentDescription,
            item.DocumentId,
            item.DocumentRejectionReason,
            item.DocumentStatus,
            item.DocumentStatusId,
            item.DocumentType,
            item.DocumentTypeId,
            item.RequestedDateTime,
            item.ReviewalDateTime,
            item.SubmittedDateTime,
            item.FileList
          );
        });
      },
      err => {
        this.error = {
          requested: err.error.Message
        };
      }
      );
  }


  getApproved(status) {
    this.error = {};
    this.account.getDocuments(true, status)
      .subscribe(
      res => {
        this.documents['approved'] = res['Documents'].map(item => {
          return new DocumentItem(
            item.DocumentDescription,
            item.DocumentId,
            item.DocumentRejectionReason,
            item.DocumentStatus,
            item.DocumentStatusId,
            item.DocumentType,
            item.DocumentTypeId,
            item.RequestedDateTime,
            item.ReviewalDateTime,
            item.SubmittedDateTime,
            item.FileList
          );
        });
      },
      err => {
        this.error = {
          approved: err.error.Message
        };
      }
      );
  }

  getPending(status) {
    this.error = {};

    this.account.getDocuments(true, status)
      .subscribe(
      res => {
        this.documents['pending'] = res['Documents'].map(item => {
          return new DocumentItem(
            item.DocumentDescription,
            item.DocumentId,
            item.DocumentRejectionReason,
            item.DocumentStatus,
            item.DocumentStatusId,
            item.DocumentType,
            item.DocumentTypeId,
            item.RequestedDateTime,
            item.ReviewalDateTime,
            item.SubmittedDateTime,
            item.FileList
          );
        });
      },
      err => {
        this.error = {
          pending: err.error.Message
        };
      }
      );
  }

  getRejected(status) {
    this.error = {};

    this.account.getDocuments(true, status)
      .subscribe(
      res => {
        this.documents['reject'] = res['Documents'].map(item => {
          return new DocumentItem(
            item.DocumentDescription,
            item.DocumentId,
            item.DocumentRejectionReason,
            item.DocumentStatus,
            item.DocumentStatusId,
            item.DocumentType,
            item.DocumentTypeId,
            item.RequestedDateTime,
            item.ReviewalDateTime,
            item.SubmittedDateTime,
            item.FileList
          );
        });
      },
      err => {
        this.error = {
          reject: err.error.Message
        };
      }
      );
  }

  viewFile(id) {
    this.error = {};

    this.account.documentView(id)
      .subscribe(
      res => {
        const byteArray = new Uint8Array(res['ByteArray']);
        const blob = new Blob([byteArray], { type: res['ContentType'] });
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(blob);
        } else {
          const objectUrl = URL.createObjectURL(blob);
          window.open(objectUrl);
        }
      },
      err => { console.log(err); }
      );
  }

}
