import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { from } from 'rxjs/observable/from';
import { AccountService } from '../../../../services/account.service';
import { parse } from 'url';
import { ContentService } from '../../../../services/content.service';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss']
})
export class UploadComponent implements OnInit {

  @Input() requested;
  @ViewChild('fileInput') fileInput: ElementRef;
  resourceStrings: any = {};
  form: FormGroup;
  loading = false;
  maxSize = 10;
  usedSize = 0;
  files: any;
  filesCount: number;
  validExtension: any[];
  constructor(private fb: FormBuilder, private account: AccountService, private copy: ContentService) {
    this.getLocalResourceStrings('casino.myaccount');
  }

  ngOnInit() {
    this.filesCount = 0;
    // this.validExtension = 
    this.createForm();
  }
  getLocalResourceStrings(key) {
    this.copy.getResourceString(key).subscribe(res => {
      for (const resString in this.resourceStrings) {
        if (res[key].hasOwnProperty(resString)) {
          this.resourceStrings[resString] = res[key][resString];
        }
      }
      console.log(this.resourceStrings);
    });
  }
  createForm() {
    this.form = this.fb.group({
      name: [''],
      docs: null
    });

    this.files = [];
  }

  onFileChange(event) {
    this.usedSize = 0;

    if (event.target.files && event.target.files.length > 0) {

      for (let i = 0; i < event.target.files.length; i++) {

        if (event.target.files[i].name.match(/.jpeg|.jpg|.png|.doc|.docx|.gif/gi)) {
          this.files.push(event.target.files[i]);
          this.usedSize += event.target.files[i].size;
          this.filesCount += 1;
        }
      }
    }
  }

  onSubmit(object) {
    const formData = new FormData();
    const testGuid = this.createGuid();

    formData.append('ItemId', testGuid);
    formData.append('DocumentId', object.DocumentId);
    formData.append('DocumentTypeId', object.DocumentTypeId);

    for (let i = 0; i < this.files.length; i++) {

      if (!this.files[i].remove) {
        formData.append('FileDataByteArrayList_' + testGuid, this.files[i]);
        formData.append('ItemName', this.files[i].name);
        this.files[i].loading = true;
        this.loadFile(formData, i);
      }
    }
  }

  loadFile(object, index) {

    if (this.usedSize < (1000 * 1000) * this.maxSize) {
      this.account.documentUploader(object)
        .subscribe(
        data => { this.files[index].success = true; },
        err => { console.log(err); }
        );
    }
  }

  removeFile(index) {
    this.filesCount -= 1;
    this.files[index].remove = true;
    this.usedSize -= this.files[index].size;
  }

  createGuid() {
    return this.s4() + this.s4() + '-' + this.s4() + '-' + this.s4() + '-' + this.s4() + '-' + this.s4() + this.s4() + this.s4();
  }

  s4() {
    return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
  }
}
