import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../../services/account.service';
import { UserService } from '../../../services/user.service';
import { ContentService } from '../../../services/content.service';

@Component({
  selector: 'app-balances',
  templateUrl: './balances.component.html',
  styleUrls: ['./balances.component.scss']
})
export class BalancesComponent implements OnInit {

  balances: any;
  resourceStrings: any = {};
  constructor(private acct: AccountService, private user: UserService, private copy: ContentService) {
    this.getLocalResourceStrings('casino.myaccount');
  }


  getLocalResourceStrings(key) {
    this.copy.getResourceString(key).subscribe(res => {
      this.resourceStrings = res;
    });
  }
  ngOnInit() {
    const token = this.user.getUser().AuthToken;

    this.acct.getBalance(token)
      .subscribe(
        res => {
          this.user.setUser('balance', res['CashBalance']);
          this.balances = res;
        },
        err => { console.log(err);
      });
  }

}
