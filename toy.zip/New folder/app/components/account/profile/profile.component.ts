import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { passwordMatch } from '../../../validators/password-match';
import { AccountService } from '../../../services/account.service';
import { UserService } from '../../../services/user.service';
import { RegistrationService } from '../../../services/registration.service';
import { ContentService } from '../../../services/content.service';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  profileForm: FormGroup;
  userForm: FormGroup;
  dobDayArr = [];
  dobMonthArr = [];
  dobYearArr = [];
  dayArr = [];
  monthArr = [];
  yearArr = [];
  regValid: boolean = false;
  passSwitch: boolean = true;
  confSwitch: boolean = true;
  currencyList: any;
  countryList: any;
  countriesLoad = false;
  provincesLoad = false;
  cityLoad = false;
  show: boolean;
  resourceStrings: any;
  docTypeList = [];
  issuedByList = [];
  sessionDurationList = [];
  validUsername = true;
  sessionLoad = true;
  constructor(
    private acct: AccountService,
    private user: UserService,
    private reg: RegistrationService,
    private copy: ContentService
  ) {
    this.show = false;
    const DOBtoday = new Date();
    let DOByear = DOBtoday.getFullYear() - 18;
    for (let i = 1; i < 32; i++) {
      this.dobDayArr.push(i);
    }
    for (let i = 1; i < 9; i++) {
      this.dobMonthArr.push(i);
    }
    for (let i = 1; i < 101; i++) {
      this.dobYearArr.push(DOByear);
      DOByear = DOByear - 1;
    }
    const today = new Date();
    let year = today.getFullYear() - 50;
    for (let i = 1; i < 32; i++) {
      this.dayArr.push(i);
    }
    for (let i = 1; i < 9; i++) {
      this.monthArr.push(i);
    }
    for (let i = 1; i < 101; i++) {
      this.yearArr.push(year);
      year = year - 1;
    }
    this.currencyList = this.reg.getCurrency();
    this.countryList = this.reg.getCountries();
    this.copy.resourceStringPackEmit.subscribe(res => {
      this.resourceStrings = res;
    }
    );
    this.copy.getResourceStringValue('casino.register');
    this.reg.idDocType().subscribe(res => {
      this.docTypeList = res['IdTypes'];
    });
    this.reg.issuedBy().subscribe(res => {
      this.issuedByList = res['IssuedBy'];
    });
    this.reg.sessionReminders().subscribe(res => {
      this.sessionLoad = false;
      this.sessionDurationList = res;
    });
  }
  
  ngOnInit() {
    this.acct.getAccountInformation()
      .subscribe(
      res => {
        this.acct.setAcctProperty('FirstName', res['FirstName']);
        this.acct.setAcctProperty('LastName', res['LastName']);
        this.acct.setAcctProperty('City', res['City']);
        this.acct.setAcctProperty('CountryCode', res['CountryCode']);
        this.acct.setAcctProperty('Currency', res['Currency']);
        this.acct.setAcctProperty('EmailAddress', res['EmailAddress']);
        this.acct.setAcctProperty('DateOfBirth', res['BirthDate']);
        this.acct.setAcctProperty('ZipPostalCode', res['PostalCode']);
        this.acct.setAcctProperty('Province', res['Province']);
        this.acct.setAcctProperty('PhoneMobile', res['MobileNumber']);
        this.acct.setAcctProperty('Address1', res['AddressLine1']);

        console.log(this.profileForm.controls);
      },
      err => {
        console.log(err);
      }
      );

      this.userForm = new FormGroup({
        LoginName: new FormControl(null, [Validators.required, Validators.maxLength(20)]),
        Password: new FormControl(null,
          [Validators.required, Validators.minLength(4), Validators.maxLength(20), Validators.pattern('^[a-zA-Z0-9_]+$')]),
      });
    this.profileForm = new FormGroup({
      FirstName: new FormControl(null, Validators.required),
      LastName: new FormControl(null, Validators.required),
      DOBDay: new FormControl(null, Validators.required),
      DOBMonth: new FormControl(null, Validators.required),
      DOBYear: new FormControl(null, Validators.required),
      CountryOfBirth: new FormControl(null, Validators.required),
      ProvinceOfBirth: new FormControl(null, Validators.required),
      CityOfBirth: new FormControl(null, Validators.required),
      CodiceFiscale: new FormControl(null, [Validators.required]),
      CountryCode: new FormControl(null, Validators.required),
      StateProvince: new FormControl(null, Validators.required),
      Address1: new FormControl(null, Validators.required),
      City: new FormControl(null, Validators.required),
      ZipPostalCode: new FormControl(null, Validators.required),
      InternationalDialingCode: new FormControl(null, Validators.required),
      PhoneMobile: new FormControl(null, Validators.required),
      EmailAddress: new FormControl(null, [Validators.required, Validators.email]),
      DocumentType: new FormControl(null, Validators.required),
      IssuedBy: new FormControl(null, Validators.required),
      IdNumber: new FormControl(null, Validators.required),
      IssuedInLocality: new FormControl(null, Validators.required),
      validFDay: new FormControl(null, Validators.required),
      validFMonth: new FormControl(null, Validators.required),
      validFYear: new FormControl(null, Validators.required),
      validTDay: new FormControl(null, Validators.required),
      validTMonth: new FormControl(null, Validators.required),
      validTYear: new FormControl(null, Validators.required),
      LoginName: new FormControl(null, [Validators.required, Validators.maxLength(20)]),
      Password: new FormControl(null,
        [Validators.required, Validators.minLength(4), Validators.maxLength(20), Validators.pattern('^[a-zA-Z0-9_]+$')]),
      confirmPassword: new FormControl({ value: null, disabled: false }, [Validators.required, passwordMatch]),
      SecurityQuestion: new FormControl(null, Validators.required),
      SecurityAnswer: new FormControl(null, Validators.required),
      SessionDurationPeriod: new FormControl(null, Validators.required),
      WeeklyDepositLimit: new FormControl(null, Validators.required),
      CurrencyCode: new FormControl(null, Validators.required)
    });
  }
  togglePassView() {
    this.passSwitch = !this.passSwitch;
  }
  toggleConfView() {
    this.confSwitch = !this.confSwitch;
  }
  checkValue(data) {
    if (data.target.value.length > 0) {
      this.profileForm.get('confirmPassword').enable();

    }
  }
  setTab() {
    this.show = !this.show;
  }
}
