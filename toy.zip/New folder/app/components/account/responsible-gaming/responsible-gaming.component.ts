import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../../services/account.service';
import { ContentService } from '../../../services/content.service';
import { AuthService } from '../../../services/auth.service';
import { element } from 'protractor';

@Component({
  selector: 'app-responsible-gaming',
  templateUrl: './responsible-gaming.component.html',
  styleUrls: ['./responsible-gaming.component.scss']
})
export class ResponsibleGamingComponent implements OnInit {
  limits: any[];
  modals: any[];
  exclusions: any[];
  exclusion: any;
  limit: number;
  resourceStrings: any = {};

  constructor(private account: AccountService, private copy: ContentService, private auth: AuthService) {
    this.getLocalResourceStrings('casino.myaccount');
  }
  getLocalResourceStrings(key) {
    this.copy.getResourceString(key).subscribe(res => {
      this.resourceStrings = res;
    });
  }
  ngOnInit() {
    this.modals = [];
    this.limit = 0;
    this.limits = [];
    this.exclusions = [];
    this.exclusion = {};
    this.account.getDepositLimit()
      .subscribe(
        data => {
          // Filter according to order
          data['DepositLimit'].forEach(value => {
            this.limits[value.DepositLimitTypeOrder] = value;
          });

          this.selected(this.limits[0], 0);
        },
        err => {
          console.log(err);
        }
      );

    this.account.getExclusionType()
      .subscribe(
        data => {
          // Filter according to order
          data['ExclusionReasons'].forEach(value => {
            this.exclusions[value.Order] = value;
          });

          this.exclude(this.exclusions[0], 0);
        },
        err => {
          console.log(err);
        }
      );
  }

  selected(item, index) {

    this.limits.map(val => val.checked = false);
    this.limits[index].checked = true;
  }

  setLimit() {
    const limitItem = [];

    this.limits.map(val => {
      limitItem.push({
        DepositLimitTypeId: val.DepositLimitTypeId,
        LimitValue: val.LimitValue,
        LanguageCode: val.LanguageCode,
        DepositLimitTypeName: val.DepositLimitTypeName,
        DepositLimitTypeOrder: val.DepositLimitTypeOrder
      });
    });

    this.account.setDepositLimit(limitItem)
      .subscribe(
        data => {
          console.log(data);
        },
        err => {
          console.log(err);
        }
      );
  }

  exclude(item, index) {
    this.exclusions.map(val => val.checked = false);
    this.exclusions[index].checked = true;
  }

  selectedExclude(item) {
    this.exclusion = {
      ExclusionPeriod: item.Period,
      ExclusionReason: item.TypeId
    };
  }

  setExclude() {
    this.auth.logOut();

    // Don't exclude for now.
    // this.account.setExclusionType(this.exclusion)
    //   .subscribe(
    //     data => {
    //       console.log(data);
    //     },
    //     err => {
    //       console.log(err);
    //     }
    //   );
  }

  open(value) {
    this.modals = [];
    this.modals[value] = true;
  }

  close() {
    this.modals = [];
  }

}
