import { FormControl } from '@angular/forms';
import { ValidatorFn } from '@angular/forms/src/directives/validators';
import { AbstractControl } from '@angular/forms';

export function passwordMatch(control: FormControl) {
    if (control.parent !== undefined) {
        return control.parent.value.Password === control.value ? null : { 'passwordMatch': true };
    }
}

