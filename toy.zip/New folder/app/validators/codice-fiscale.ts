import { FormControl } from '@angular/forms';

export function codiceValidator(control: FormControl) {
  let code = control.value;
  
  if (code !== null && code !== undefined) {
    let year = control.parent.value['DOBYear'].toString();    
    if (code.length === 16) {
      if (code[6] == year[2] && code[7] == year[3]){
        return null;
      }
      
    }
    return {
      codiceValidator: {
        valid: false
      }
    }
  }

};