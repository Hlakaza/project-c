export class Message {
    nickName: string;
    text: string;
    type: string;
    notification: boolean;
    initial: string;
    isTyping: boolean;
    isPushUrl: boolean;

    constructor(obj?: any) {
        this.nickName = obj.nickName;
        this.text = obj.text;
        this.type = obj.type;
        this.notification = obj.notification;
        this.initial = this.splitNickname(this.nickName);
        this.isTyping = obj.isTyping || false;
        this.isPushUrl = obj.isPushUrl || false;
    }

    // When the Class gets intialized and passed with nickName splitNickname just gets the intial or the first and last name
    public splitNickname(fullName: any): string {
        let initials = fullName.match(/\b\w/g) || [];
        initials = ((initials.shift() || '') + (initials.pop() || '')).toUpperCase();
        return initials;
    }
}
