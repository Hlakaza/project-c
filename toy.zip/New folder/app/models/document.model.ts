export class DocumentItem {
    constructor (
        public DocumentDescription: string,
        public DocumentId: string,
        public DocumentRejectionReason: string,
        public DocumentStatus: string,
        public DocumentStatusId: string,
        public DocumentType: string,
        public DocumentTypeId: string,
        public RequestedDateTime: string,
        public ReviewalDateTime: string,
        public SubmittedDateTime: string,
        public FileList: FileItem) {
    }
}

export class FileItem {
    constructor (
        public DocumentId: string,
        public DocumentImageId: string,
        public FileName: string) {
    }
}