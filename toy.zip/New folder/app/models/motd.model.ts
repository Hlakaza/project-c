export class MotdItem {
    constructor (
        public AbsolutePath: string,
        public ContentPath: string,
        public HtmlFilePath: string,
        public MotdId: string,
        public PromotionId: string,
        public Title: string) {
    }
}
