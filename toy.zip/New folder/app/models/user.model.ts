export class User {
    firstName: string;
    lastName: string;
    subject: string;
    email: string;
    nickName: string;
    userDetail: any;
    type: string;

    constructor(obj?: any) {
        this.firstName = obj.firstName;
        this.lastName = obj.lastName;
        this.subject = obj.subject;
        this.email = obj.email;
        this.nickName = obj.nickName;
        this.userDetail = obj.userDetail;
        this.type = obj.type;
    }

}
