import { TestBed, inject } from '@angular/core/testing';

import { RmmService } from './rmm.service';

describe('RmmService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RmmService]
    });
  });

  it('should be created', inject([RmmService], (service: RmmService) => {
    expect(service).toBeTruthy();
  }));
});
