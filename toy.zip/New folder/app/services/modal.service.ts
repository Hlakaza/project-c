import { Injectable, Output, EventEmitter } from '@angular/core';

@Injectable()
export class ModalService {
  @Output() toggleModal: EventEmitter<String> = new EventEmitter<String>();
  @Output() bodyModal: EventEmitter<String> = new EventEmitter<String>();

  open(id: string, bgUrl: string) {
    this.setModal('open', id, bgUrl);
  }

  close(id: string) {
    this.setModal('close', id, null);
  }

  setModal(type: string, id: string, bgUrl: string) {
    this.toggleModal.emit(`${type},${id},${bgUrl}`);
    this.getModal();
  }

  clearAll() {
    this.toggleModal.emit('clear');
    this.getModal();
  }

  getModal() {
    return this.toggleModal;
  }

  setContent(value: any) {
    this.bodyModal.emit(`${value}`);
    this.getContent();
  }

  getContent() {
    return this.bodyModal;
  }

}
