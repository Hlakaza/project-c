import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { XmlToJsonPipe } from '../pipes/xml-to-json.pipe';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
@Injectable()
export class UserService {
  api = (<any>window).global.variables.api;
  version = '1.0';
  urls = {
    xman: 'https://xplay2.gameassists.it/Xman/x.x'
  };
  user = {
    LoginName: '',
    Password: '',
    XmanSessionToken: '',
    RaptorSessionToken: '',
    AuthToken: '',
    EmailCount: '',
    rmmCount: '',
    balance: '',
    bonusBalance: 0,
    cashBalance: 0,
    CultureCode: '',
    BrandCode: '',
    CasinoCode: 0,
    LangCode: '',
    FCIP: '',
    mgsUserID: 0,
    msgCount: 0,
    CurrencyCode: ''
  };

  constructor(private http: HttpClient) {
    this.setUser('BrandCode', (<any>window).global.request.BrandCode);
    // this.setUser('BrandCode', 'RV');
    this.setUser('CultureCode', (<any>window).global.request.culture);
    this.setUser('LangCode', 'EN');
  }

  get msgCount() {
    return this.getUser().msgCount;
  }

  get balance() {
    return this.getUser().balance;
  }

  setUser(key, value) {
    this.user[key] = value;
  }

  getUser() {
    localStorage.setItem('vdvUser', JSON.stringify(this.user));
    return this.user;
  }
}
