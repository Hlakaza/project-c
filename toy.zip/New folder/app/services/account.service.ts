import {
  Injectable
} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DocumentItem } from '../models/document.model';
import { UserService } from './user.service';

@Injectable()
export class AccountService {
  api = (<any>window).global.variables.api;
  version = '1.0';
  account = {
    FirstName: '',
    LastName: '',
    DateOfBirth: null,
    CountryOfBirth: '',
    ProvinceOfBirth: '',
    CityOfBirth: '',
    CodiceFiscale: '',
    CountryCode: '',
    StateProvince: '',
    StateIsoCode: '',
    Address1: '',
    Address2: '',
    City: '',
    ZipPostalCode: '',
    InternationalDialingCode: '',
    PhoneMobile: '',
    PhoneWork: '',
    PhoneHome: '',
    FaxNumber: '',
    BannerTag: '',
    BannerTag4: '',
    EmailAddress: '',
    DocumentType: '',
    IssuedBy: '',
    IdNumber: '',
    IssuedInLocality: '',
    ValidFrom: null,
    ValidTo: null,
    SecurityQuestion: '',
    SecurityAnswer: '',
    SessionDurationPeriod: '',
    WeeklyDepositLimit: 0,
    CurrencyCode: '',
    AcceptedLegalContract: false,
    legalAge: false,
    PrivacyPolicy: false,
    IncludeInCommunications: false
  };

  constructor(private http: HttpClient, private user: UserService) {
  }
  getAccountInformation() {
    let url = `${this.api}/api/v${this.version}/Account/Information`;
    url += `?brandCode=${this.user.getUser().BrandCode}&culturecode=${this.user.getUser().CultureCode}`;
    return this.http.get(url);
  }

  getAcctProperty(parm) {
    if (parm === 'all') {
      return this.account;
    } else {
      if (this.account.hasOwnProperty(parm)) {
        return this.account[parm];
      }
    }
  }
  setAcctProperty(key, value) {
    if (this.account.hasOwnProperty(key)) {
      this.account[key] = value;
    }
  }

  getBalance(token) {
    let url = `${this.api}/api/v${this.version}/Balance`;
    url += `?brandCode=${this.user.getUser().BrandCode}`;
    url += `&culturecode=${this.user.getUser().CultureCode}`;

    return this.http.get(url);
  }

  getEmails() {
    let url = `${this.api}/api/v${this.version}/EmailMessages`;
    url += `?brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;

    return this.http.get(url);
  }

  getInbox() {
    let url = `${this.api}/api/v${this.version}/Inbox`;
    url += `?brandCode=${this.user.getUser().BrandCode}&culturecode=${this.user.getUser().CultureCode}`;

    return this.http.get(url);
  }

  getInboxCount() {
    let url = `${this.api}/api/v${this.version}/Inbox/Count`;
    url += `?brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;

    return this.http.get(url);
  }

  getDocuments(refreshData, statusId) {
    let url = `${this.api}/api/v${this.version}/Document`;
    url += `?statusId=${statusId}`;
    url += `&refreshData=${refreshData}`;
    url += `&brandCode=${this.user.getUser().BrandCode}`;
    url += `&cultureCode=${this.user.getUser().CultureCode}`;

    return this.http.get(url);
  }

  documentUploader(formData) {
    let url = `${this.api}/api/v${this.version}/Document/Upload`;
    url += `?brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;
    return this.http.post(url, formData);
  }

  documentView(fileId) {
    let url = `http://api.gmgamingsystems.com.dev.labenv/api/v1.0/Document/File`;
    url += `?fileId=${fileId}&brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;

    return this.http.get(url);
  }

  getLoyalty() {
    let url = `${this.api}/api/v${this.version}/Loyalty`;
    url += `?brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;

    return this.http.get(url);
  }

  getDepositLimit() {
    let url = `${this.api}/api/v${this.version}/ResponsibleGaming/DepositLimits`;
    url += `?brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;

    return this.http.get(url);
  }

  setDepositLimit(data) {
    let url = `${this.api}/api/v${this.version}/ResponsibleGaming/DepositLimits`;
    url += `?brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;

    const body = {
      DepositLimit: data
    };

    return this.http.put(url, body);
  }

  getExclusionType() {
    let url = `${this.api}/api/v${this.version}/ResponsibleGaming/ExclusionType`;
    url += `?brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;

    return this.http.get(url);
  }

  setExclusionType(exclusion) {
    let url = `${this.api}/api/v${this.version}/ResponsibleGaming/Exclusion`;
    url += `?brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;

    const body = exclusion;

    return this.http.put(url, body);
  }

  loyaltyClaim(pointAmount) {
    let url = `${this.api}/api/v${this.version}/Loyalty/Claim`;
    url += `?&brandcode=${this.user.getUser().BrandCode}&culturecode=${this.user.getUser().CultureCode}`;
    const body = { 'PointAmount': pointAmount };
    return this.http.post(url, body);
  }
  changePassword(oldPassword, newPassword) {
    let url = `${this.api}/api/v${this.version}/CheckExistingLoginName`;
    url += `?brandCode=${this.user.getUser().BrandCode}&culturecode=${this.user.getUser().CultureCode}`;

    const body = {
      'OldPassword': oldPassword,
      'NewPassword': newPassword
    };

    return this.http.put(url, body);
  }
}

