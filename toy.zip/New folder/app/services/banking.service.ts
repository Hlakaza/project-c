import { Injectable} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserService } from './user.service';

@Injectable()
 export class BankingService {

    constructor(private http: HttpClient, private user: UserService) {}

    getBanking() {
        let url = `http://api.gmgamingsystems.com.dev.labenv/api/v1.0/Banking/MobileDetails`;
        url += `?brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;
        return this.http.get(url);
      }
}
