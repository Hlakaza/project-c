import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';

@Injectable()
export class CookieBarService {
  cookieValue: any;
  showCookieBar = true;
  constructor(
    private cookieService: CookieService
  ) { }

  isCookieHidden() {
    this.cookieValue = this.cookieService.get('COOKIEBAR');
    this.cookieValue === 'hidden' ? this.showCookieBar = false : this.showCookieBar = true;
    this.cookieService.set('COOKIEBAR', 'hidden');
    return this.showCookieBar;
  }

}
