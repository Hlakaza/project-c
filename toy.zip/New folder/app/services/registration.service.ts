import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UserService } from './user.service';
import { GlobalInfoService } from './global-info.service';

@Injectable()
export class RegistrationService {
  api = (<any>window).global.variables.api;
  version = '1.0';
  currencyList: any;
  @Output() countryList: any = new EventEmitter<boolean>();
  @Output() provinceList: any = new EventEmitter<boolean>();
  @Output() birthProvinceList: any = new EventEmitter<boolean>();
  countryRepo: any;
  provinceRepo: any;
  birthProvinceRepo: any;
  firstCountry: any;
  constructor(private http: HttpClient, private user: UserService, private globalinfo: GlobalInfoService) { }

  countryCall() {
    let url = `${this.api}/api/v${this.version}/Register/Countries`;
    url += `?brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;
    return this.http.get(url).map(res => {
      this.countryRepo = res;
      this.countryList.emit(this.countryRepo);
    });
  }
  birthProvinceCall(country) {
    let url = `${this.api}/api/v${this.version}/Register/BirthProvince`;
    url += `?countryCode=${country}&brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;
    return this.http.get(url).map(res => {
      this.firstCountry = country;
      this.birthProvinceRepo = res;
      this.birthProvinceList.emit(res);
      return res;
    });
  }
  provinceCall(country) {
    let url = `${this.api}/api/v${this.version}/Register/Province`;
    url += `?countryCode=${country}&brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;
    return this.http.get(url).map(res => {
      this.firstCountry = country;
      this.provinceRepo = res;
      this.birthProvinceList.emit(res);
      return res;
    });
  }
  cityCall(provice) {
    let url = `${this.api}/api/v${this.version}/Register/Community`;
    url += `?provinceCode=${provice}&brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;
    return this.http.get(url).map(res => {
      return res['Communities'];
    });
  }
  getCountries() {
    return this.countryRepo;
  }
  getProvinces(country) {
    if (country === this.firstCountry) {
      this.provinceList(this.provinceRepo);
    } else {
      this.provinceCall(country);
    }

  }

  getCurrency() {
    this.currencyList = this.globalinfo.metaData.CurrenciesInLanguage;
    return this.currencyList;
  }

  idDocType() {
    let url = `${this.api}/api/v${this.version}/Register/IdentityDocumentType`;
    url += `?&brandcode=${this.user.getUser().BrandCode}&culturecode=${this.user.getUser().CultureCode}`;
    return this.http.get(url);
  }
  issuedBy() {
    let url = `${this.api}/api/v${this.version}/Register/IdentityDocumentIssuedBy`;
    url += `?&brandcode=${this.user.getUser().BrandCode}&culturecode=${this.user.getUser().CultureCode}`;
    return this.http.get(url);
  }
  checkExistingLoginName(username, casinoId) {
    let url = `${this.api}/api/v${this.version}/Register/CheckExistingLoginName`;
    url += `?brandCode=${this.user.getUser().BrandCode}&culturecode=${this.user.getUser().CultureCode}`;

    const body = {
      'CasinoId': casinoId,
      'UserName': username
    };

    return this.http.post(url, body).map(res => {
      return res;
    });
  }
  sessionReminders() {
    let url = `${this.api}/api/v${this.version}/Register/SessionReminders`;
    url += `?&brandcode=${this.user.getUser().BrandCode}&culturecode=${this.user.getUser().CultureCode}`;
    return this.http.get(url).map(res => {
      res = res['BSR'].sort((a, b) => {
        if (a.Id > b.Id) {
          return 1;
        }
        if (a.Id < b.Id) {
          return -1;
        }
        if (a.Id === b.Id) {
          return 0;
        }
      });
      return (<any>res);
    });
  }
}
