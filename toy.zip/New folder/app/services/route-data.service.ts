import { Injectable, EventEmitter, Output } from '@angular/core';
import { Router, ResolveEnd, ActivationStart, ActivatedRoute, NavigationEnd, NavigationStart } from '@angular/router';
import { ModalService } from './modal.service';
import { Title } from '@angular/platform-browser';
import { Location } from '@angular/common';
import { GameService } from './game.service';




@Injectable()
export class RouteDataService {
  @Output() copyData = new EventEmitter<any>();
  @Output() urlData = new EventEmitter<any>();
  @Output() aliasData = new EventEmitter<any>();
  @Output() promotionBlocks = new EventEmitter<any>();
  @Output() secondaryBanner = new EventEmitter<any>();
  @Output() gameData = new EventEmitter<any>();
  queryData: any;
  constructor(private router: Router,
    private activeRoute: ActivatedRoute,
    private modal: ModalService,
    private titleService: Title,
    private location: Location,
    private game: GameService
  ) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        window.scrollTo(0, 0);
        if (event.url.indexOf('btag-') !== -1) {
          this.router.navigate([event.url.replace(/btag-([a-z0-9\\-]*)/, '')]);
        }
        if (event.url.indexOf('play.now') !== -1) {
          this.router.navigate([event.url.replace(/play.now/, '')]);
        }
      }

      if (event instanceof ActivationStart) {

        this.titleService.setTitle(event.snapshot.data.pageTitle);
        this.copyData.emit(event.snapshot.data);
        this.urlData.emit(event.snapshot.url);
        this.gameData.emit(this.gameHandler(event.snapshot.url));
        this.queryData = event.snapshot.queryParams;
      }
      if (event instanceof NavigationEnd) {
        if (this.queryData.hasOwnProperty('popup')) {
          if (this.queryData.popup === 'register') {
            setTimeout(() => {
              this.modal.open('register', '');
            }, 3000);
          }
        }
        if (this.queryData.hasOwnProperty('launchGame')) {
          console.log('Query data', this.queryData.launchGame);
          this.game.getGameObjFromLBId(this.queryData.launchGame).subscribe(res => {
            setTimeout(() => {
              this.modal.open('game-overlay', '');
              this.game.getGameLaunchURL(res['Gid'], false).subscribe();
            }, 3000);
          });
        }
      }
    });
  }
  getAlias() {
    this.router.config.filter((value) => {
      if (value.data !== undefined) {
        if (value.data.alias === 'Promotion-Blocks') {
          this.promotionBlocks.emit(value.data.value);
        }
        if (value.data.alias === 'Offer-Banner-Secondary') {
          this.secondaryBanner.emit(value.data.value);
        }
      }
    });

  }
  gameSearch(GLId) {

  }
  gameHandler(urlData) {
    if (urlData.length === 0) {
      return { showGames: true, full: false, path: '' };
    } else if (urlData[0].path === 'Giochi') {
      if (urlData.length > 1) {
        return { showGames: true, full: true, path: urlData[1].path };
      } else {
        return { showGames: true, full: false, path: '' };
      }
    } else {
      return { showGames: false, full: true, path: '' };
    }
  }
}

