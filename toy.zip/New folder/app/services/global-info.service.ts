import { Injectable, EventEmitter, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserService } from './user.service';

@Injectable()
export class GlobalInfoService {
  api = (<any>window).global.variables.api;
  version = '1.0';
  @Output() countriesInLang = new EventEmitter<any>();
  @Output() langsInLang = new EventEmitter<any>();
  @Output() currencyInLang = new EventEmitter<any>();
  @Output() brandExtensions = new EventEmitter<any>();
  metaData = {
    LanguagesInLanguage: [],
    CurrenciesInLanguage: [],
    CountriesInLanguage: [],
    BrandExternalApplications: [],
    PlatformTypeId: '',
    CasinoId: 0,
    RmmUrl: '',
    CountryCode: ''
  };
  constructor(private http: HttpClient, private user: UserService) { }
  getMetaData() {
    let url = `${this.api}/api/v${this.version}/MetaData`;
    // url += `?brandCode=${this.user.BrandCode}&cultureCode=${this.user.CultureCode}`;
    url += `?brandCode=RV&cultureCode=${this.user.getUser().CultureCode}`;
    return this.http.get(url).map(res => {
      this.metaData.CountriesInLanguage = res['CountriesInLanguage'];
      this.metaData.LanguagesInLanguage = res['LanguagesInLanguage'];
      this.metaData.CurrenciesInLanguage = res['CurrenciesInLanguage'];
      this.metaData.BrandExternalApplications = res['BrandExternalApplications'];
      this.currencyInLang.emit(res['CurrenciesInLanguage']);
      this.brandExtensions.emit(res['BrandExternalApplications']);
      return res;
    });
  }
  getRequestMetaData() {
    let url = `${this.api}/api/v${this.version}/MetaData/Request`;
    url += `?brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;
    return this.http.get(url).map(res => {
      this.metaData.PlatformTypeId = res['PlatformTypeId'];
      this.metaData.CasinoId = res['CasinoId'];
      this.metaData.RmmUrl = res['RmmUrl'];
      this.metaData.CountryCode = res['CountryCode'];
      return res;
    });
  }
}
