import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/delay';
import 'rxjs/add/observable/of';
import { UserService } from './user.service';
import { AuthService } from './auth.service';

@Injectable()
export class GameService {
    @Output() gameCats: EventEmitter<any> = new EventEmitter<any>();
    @Output() gameLaunchObj: EventEmitter<any> = new EventEmitter<any>();
    version = '1.0';
    api = (<any>window).global.variables.api;
    storedGameCats: any = [];
    gamesRepo: any = {};
    gameLaunchRepo: any = {
        loggedOut: {},
        loggedIn: {}
    };
    constructor(private http: HttpClient, private user: UserService, private auth: AuthService) { }
    setStoredGameCats(arr) {
        this.storedGameCats = arr;
    }
    getStoredGameCats() {
        return this.storedGameCats;
    }

    setGamesRepo(GCId, arr) {
        this.gamesRepo[GCId] = arr;
    }
    getGamesRepo(GCId) {
        return this.gamesRepo[GCId];
    }
    setGameLaunchRepo(GId, auth, data) {
        if (auth) {
            this.gameLaunchRepo.loggedIn[GId] = data;
        } else {
            this.gameLaunchRepo.loggedOut[GId] = data;
        }
    }
    getGameLaunchRepo(GId, auth) {
        if (auth) {
            return this.gameLaunchRepo.loggedIn[GId];
        } else {
            for (const key in this.gameLaunchRepo.loggedOut) {
                if (key === GId) {
                    return this.gameLaunchRepo.loggedOut[GId];
                }
            }
            return this.gameLaunchRepo.loggedOut[GId];
        }
    }

    getGameCat() {
        let url = `${this.api}/api/v${this.version}/Games/Categories/`;
        url += `?brandCode=${this.user.getUser().BrandCode}&culturecode=${this.user.getUser().CultureCode}`;
        return this.http.get(url).map(res => {
            const whiteList = [
                'cb3a1eb4-2c9c-4c23-80ce-500a566b1222',
                'f20b2c2f-c6a6-41da-8af7-bab31d5574e1',
                '312c419d-e3f4-4c51-b575-26810d88e5ca'
            ];
            res = res['GC'].filter((value) => {
                if (whiteList.indexOf(value.GCId) !== -1) {
                    if (value.GCN.toLowerCase().indexOf('slots') === -1 && value.GCN.toLowerCase().indexOf('slot') !== -1) {
                        value.GCN = value.GCN + 's';
                    }
                    value.NP = value.GCN.split(' ').map((val) => {
                        return val.charAt(0).toUpperCase() + val.substr(1).toLowerCase();
                    }).join('-');
                    value.NP = '/Giochi/' + value.NP;

                    return value;
                }
            });
            this.setStoredGameCats(res);
            this.gameCats.emit(this.getStoredGameCats());
            return res;

        },
            err => {
                console.log(err);
            }
        );
    }
    getGameLaunchURL(GId, caching) {
        let url = `${this.api}/api/v${this.version}/Games/`;
        if (this.auth.isAuthenticated) {
            if (this.gameLaunchRepo.loggedIn.hasOwnProperty(GId)) {
                if (!caching) {
                    this.gameLaunchObj.emit(this.getGameLaunchRepo(GId, true));
                }
                return Observable.of(this.getGameLaunchRepo(GId, true));
            } else {
                url += `Real/Launch/`;
                url += `?gameId=${GId}`;
                url += `&xmanSessionToken=${GId}`;
                url += `&raptorSessionToken=${GId}`;
                url += `&isCultureLookup=true&brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;
                return this.http.get(url).map(res => {
                    this.setGameLaunchRepo(GId, true, res);
                    if (!caching) {
                        this.gameLaunchObj.emit(res);
                    }
                    return res;

                });
            }

        } else {
            if (this.gameLaunchRepo.loggedOut.hasOwnProperty(GId)) {
                if (!caching) {
                    this.gameLaunchObj.emit(this.getGameLaunchRepo(GId, false));
                }
                return Observable.of(this.getGameLaunchRepo(GId, false));
            } else {
                url += `Free/Launch/`;
                url += `?gameId=${GId}`;
                // url += `&isCultureLookup=true&brandCode=${this.user.getUser().BrandCode}&cultureCode=${this.user.getUser().CultureCode}`;
                url += `&isCultureLookup=true&brandCode=RV&cultureCode=${this.user.getUser().CultureCode}`;
                return this.http.get(url).map(res => {
                    this.setGameLaunchRepo(GId, false, res);
                    if (!caching) {
                        this.gameLaunchObj.emit(res);
                    }
                    return res;

                });
            }
        }
    }

    getGames(skip?, limit?, search?, GCId?) {
        let url = `${this.api}/api/v${this.version}/Games/?`;
        if (skip !== null) {
            url += `isCultureLookup=true&skip=${skip}&`;
        }
        if (limit !== null) {
            url += `limit=${limit}&`;
        }
        if (search !== null) {
            url += `search=${search}&`;
        }
        if (GCId !== null) {
            url += `gameCategoryId=${GCId}&`;
        }
        url += `brandCode=${this.user.getUser().BrandCode}&culturecode=${this.user.getUser().CultureCode}`;
        return this.http.get(url).map(res => {
            if (skip === 0 && GCId !== null) {
                this.setGamesRepo(GCId, res);
            }
            return res;
        });

    }

    getFeaturedGames() {
        let url = `${this.api}/api/v${this.version}/Games/?`;
        url += `gameCategoryId=0790e4d3-74a8-47f2-b255-a22496d8681f&`;
        url += `brandCode=${this.user.getUser().BrandCode}&culturecode=${this.user.getUser().CultureCode}`;
        return this.http.get(url).map(res => { });
    }
    getGameObjFromLBId(id) {
        let url = `${this.api}/api/v${this.version}/Game/?`;
        url += `lightBoxId=${id}&`;
        // url += `brandCode=${this.user.getUser().BrandCode}&culturecode=${this.user.getUser().CultureCode}`;
        url += `brandCode=RV&culturecode=${this.user.getUser().CultureCode}`;
        return this.http.get(url);
    }

}



