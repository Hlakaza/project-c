import { TestBed, inject } from '@angular/core/testing';

import { MotdService } from './motd.service';

describe('MotdService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MotdService]
    });
  });

  it('should be created', inject([MotdService], (service: MotdService) => {
    expect(service).toBeTruthy();
  }));
});
