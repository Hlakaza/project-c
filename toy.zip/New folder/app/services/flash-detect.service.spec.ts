import { TestBed, inject } from '@angular/core/testing';

import { FlashDetectService } from './flash-detect.service';

describe('FlashDetectService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FlashDetectService]
    });
  });

  it('should be created', inject([FlashDetectService], (service: FlashDetectService) => {
    expect(service).toBeTruthy();
  }));
});
