import { Injectable, EventEmitter, Output } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { XmlToJsonPipe } from '../pipes/xml-to-json.pipe';
import { UserService } from './user.service';

@Injectable()
export class AuthService {
  @Output() toggleAuth: EventEmitter<Boolean> = new EventEmitter<Boolean>();

  api = (<any>window).global.variables.api;
  version = '1.0';
  path = `${this.api}/api/v${this.version}`;
  xPath = `https://xplay2.gameassists.it/Xman/x.x`;

  constructor(private http: HttpClient, private user: UserService) { }

  get token() {
    return this.user.getUser().AuthToken;
  }

  get isAuthenticated() {
    if (this.user.getUser().AuthToken.match(/Bearer/g) && (this.user.getUser().AuthToken.length > 10)) {
      this.toggleAuth.emit(!!this.user.getUser().AuthToken);
      return true;
    } else {
      this.toggleAuth.emit();
      return false;
    }
  }

  getAuth() {
    return this.toggleAuth;
  }

  login(username, password) {
    let body = `<Pkt>`;
    body += `<Id mid="1" cid="10001"`;
    body += ` sid="${this.user.getUser().CasinoCode}" sessionid="" verb="SingleSignOn" clientLang="${this.user.getUser().LangCode}" />`;
    body += `<Request><FC ID1="" ID2="" IPAddress="10.0.0.1" />`;
    body += `<Credentials SSName="${username}" SSPass="${password}" clientType="1" userType="0"`;
    body += ` langCode="${this.user.getUser().LangCode}" />`;
    body += `<OldCred RUN="${username}" RPWD="${password}" PUN="${username}" PPWD="${password}" />`;
    body += `</Request></Pkt>`;

    return this.http.post(this.xPath, body, { responseType: 'text' }).map(res => {
      const transformedRes = new XmlToJsonPipe().transform(res);
      return transformedRes;
    });
  }

  loginMGS() {
    const params = `/Account/GetAuthToken?brandCode=${this.user.getUser().BrandCode}&culturecode=${this.user.getUser().CultureCode}`;
    return this.http.get(this.path + params);
  }

  keepAlivePing(xmanSessionToken) {
    const body = `<Pkt>
      <Id mid="0" cid="10001" sid="${this.user.getUser().CasinoCode}" sessionid="${xmanSessionToken}" verb="Ping" />
      <Request><FC IPAddress="10.0.0.1" /></Request>
    </Pkt>`;

    return this.http.post(this.xPath, body, { responseType: 'text' }).map(res => {
      const transformedRes = new XmlToJsonPipe().transform(res);
      return transformedRes;
    });
  }

  resetPassword(name) {

    const params = `/Password/ResetRequest?brandCode=${this.user.getUser().BrandCode}&culturecode=${this.user.getUser().CultureCode}`;
    const body = {
      CasinoId: this.user.getUser().CasinoCode,
      Username: name,
      IsResetUrlRequired: true
    };

    return this.http.post(this.path + params, body);
  }

  logOut() {
    this.user.setUser('AuthToken', '');
  }
}
