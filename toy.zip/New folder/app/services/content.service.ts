import { Injectable, Output, EventEmitter } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { HttpClient } from '@angular/common/http';


const actualCopy = {
  'Page': {
    'PCM': {
      'WP': [
        {
          'WPC': ''
        }
      ]
    }
  }
};


@Injectable()
export class ContentService {

  private version = '1.0';
  private contentApi = (<any>window).global.variables.cms;
  resourceStringPack = {};
  @Output() resourceStringPackEmit = new EventEmitter<any>();
  host: any = (<any>window).global.request.host;
  copy: any = actualCopy.Page.PCM;

  constructor(private http: HttpClient) { }

  getContentByGuid(pageGuid) {
    if (pageGuid !== undefined) {
      let url = `${this.contentApi}/gmapi/content/get/`;
      url += `?host=${this.host}`;
      url += `&pageGuid=${pageGuid}`;
      return this.http.get(url).map(res => {
        return res['Page']['PCM'];
      });
    }

  }
  getResourceString(key) {
    let url = `${this.contentApi}/gmapi/resource/get/`;
    url += `?host=${this.host}`;
    url += `&key=${key}`;
    this.resourceStringPack[key] = {};
    return this.http.get(url).map(res => {
      res['resourceStringInfo'].map((value) => {
        let string = value.Key;
        string = string.substring(string.lastIndexOf('.') + 1, string.length);
        this.setResourceString(string, value.Text);
        this.resourceStringPackEmit.emit(this.resourceStringPack);
      });
    });
  }

  setResourceString(key, value) {
    this.resourceStringPack[key] = value;
  }
  getResourceStringValue(key) {
    if (this.resourceStringPack.hasOwnProperty(key)) {
      this.resourceStringPackEmit.emit(this.resourceStringPack);
    } else {
      this.getResourceString(key).subscribe();
    }

  }
}


