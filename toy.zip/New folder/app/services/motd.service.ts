import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UserService } from './user.service';

@Injectable()
export class MotdService {
  private version = '1.0';
  private api = (<any>window).global.variables.api;
  constructor(private http: HttpClient, private user: UserService) {}

  getMotds() {
    let url = `${this.api}/api/v${this.version}/Motd`;
    url += `?brandCode=${this.user.getUser().BrandCode}`;
    url += `&cultureCode=${this.user.getUser().CultureCode}`;

    return this.http.get(url);
  }

  getMotdInformation(motdId, promotionContentPath, infoTextFileName) {
    let url = `${this.api}/api/v${this.version}/Motd/Information`;
    url += `?motdId=${motdId}`;
    url += `&promotionContentPath=${promotionContentPath}`;
    url += `&infoTextFileName=${infoTextFileName}`;
    url += `&brandCode=${this.user.getUser().BrandCode}`;
    url += `&cultureCode=${this.user.getUser().CultureCode}`;

    return this.http.get(url);
  }

}
