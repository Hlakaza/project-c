import { Injectable, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Message } from '../models/message.model';
import { Chat } from '../models/chat.model';
import { User } from '../models/user.model';

@Injectable()
export class ChatService {
  @Output() msgContent: EventEmitter<Object> = new EventEmitter<Object>();

  private serviceID;
  private messages: Message[] = [];
  private chat: Chat;
  private pageSource: string;
  private userData: User;
  private client: Message = null;
  private agent: Message = null;
  private url: string;
  private genesysChatParams: any;
  private transcriptPosition: any;

  constructor(private http: HttpClient) {
    const data: any = this.getURL();

    this.genesysChatParams = {
      requestPath: this.url,
      serviceId: null,
      chatSessionId: null,
      transcriptPosition: null,
      chatActive: false,
      messageId: null,
      messageState: null
    };
  }

  setMessage(value: any) {

    this.msgContent.emit(value);
    this.getMessage();
  }

  getMessage() {
    return this.msgContent;
  }

  initiateChat() {
    return this.http.post(`${this.url}/request-chat`, '');
  }

  startChat(serviceId, chatParams) {
    this.serviceID = serviceId;
    const requestUrl = `${this.url}/${this.serviceID}/ixn/chat`;

    // Build Chat Subject.
    let subject = ``;
    subject += `BrandCode:${chatParams.brandCode}`;
    subject += `||LanguageCode:${chatParams.langCode}`;
    subject += `||IsMobile:${chatParams.isMobile}`;
    subject += `||AccountNumber:${chatParams.accountId}`;
    subject += `||Skill:${chatParams.skill}`;
    subject += `||CasinoID:${chatParams.casinoId}`;
    subject += `||CountryCode:${chatParams.countryCode}`;
    subject += `||IPAddress:${chatParams.ipAddress}`;
    subject += `||IsLoggedIn:${chatParams.isAuth}`;
    subject += `||AccountId:${chatParams.accountId}`;
    subject += `||Name:${chatParams.name}`;

    // Add Chat Subject
    let msgParams = ``;
    msgParams = `?subject=${subject}`;
    msgParams += `&firstName=${chatParams.name}`;
    msgParams += `&lastName=''`;
    msgParams += `&email=''`;
    msgParams += `&userDisplayName=${chatParams.name}`;

    return this.http.post(requestUrl + msgParams, '');
  }

  endChat() {
    const requestUrl = `${this.url}/${this.serviceID}/ixn/chat/disconnect`;
    return this.http.post(requestUrl, '');
  }

  startTyping() {
    const requestUrl = `${this.url}/${this.serviceID}/ixn/chat/startTyping`;
    return this.http.post(requestUrl, '');
  }

  stopTyping() {
    const requestUrl = `${this.url}/${this.serviceID}/ixn/chat/stopTyping`;
    return this.http.post(requestUrl, '');
  }

  sendChatMessage(msg) {
    const requestUrl = `${this.url}/${this.serviceID}/ixn/chat/send`;
    return this.http.post(requestUrl, `message=${msg}`);
  }

  pollMessageSuccess(json) {
    this.transcriptPosition = json.transcriptPosition;

    if (json.chatIxnState === 'DISCONNECTED') {
      this.setMessage('DISCONNECTED');
    }

    this.setMessage(json);
  }

  pollChatMessages() {
    let requestUrl = `${this.url}/${this.serviceID}/ixn/chat/refresh`;
    requestUrl += `?&transcriptPosition=${this.transcriptPosition}`;

    return this.http.post(requestUrl, '');
  }

  refreshMsg(serviceID, transcript) {
    let requestUrl = `${this.url}/${serviceID}/ixn/chat/refresh`;
    requestUrl += `?&transcriptPosition=${transcript}`;

    return this.http.post(requestUrl, '');
  }

  getURL() {
    const environment = window.location.hostname;
    if (environment === 'localhost') {
      // this.url = 'http://otlabgfw01:8080/genesys/1/service';
      this.url = 'http://otlabges01:8080/genesys/1/service';
    } else {
      this.url = `http://${environment}/api/genesys`;
    }
  }

}
