import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { XmlToJsonPipe } from '../pipes/xml-to-json.pipe';
import { UserService } from './user.service';
@Injectable()
export class RmmService {
  rmmURL = 'https://rmm2.valueactive.it/vpb/';

  urls = {
    xman: 'https://xplay2.gameassists.it/Xman/x.x'
  };
  constructor(private http: HttpClient, private user: UserService) {


  }
  getRmmCnt(casinoCode, XmanSessionToken) {
    let getCount = `<Pkt>`;
    getCount += `<Id mid="130" cid="1" sid="${casinoCode}" sessionid="${XmanSessionToken}" verb="VP_GETNUMMESSAGES" /><Request />`;
    getCount += `</Pkt>`;

    return this.http.post(this.urls.xman, getCount, { responseType: 'text' }).map(res => {
      const transformedRes = new XmlToJsonPipe().transform(res);
      if (transformedRes.Pkt.Response !== undefined) {
        if (transformedRes.Pkt.Response.NumMessages.NodeAttributes.count > 0) {
          this.user.setUser('rmmCount', transformedRes.Pkt.Response.NumMessages.NodeAttributes.count);
        }
      }

      return transformedRes;
    });
  }

  getRmmContent(casinoCode, XmanSessionToken) {
    let getContent = `<Pkt>`;
    getContent += `<Id mid="130" cid="1" sid="${casinoCode}" sessionid="${XmanSessionToken}" verb="VP_GETNEXTMESSAGE" /><Request />`;
    getContent += `</Pkt>`;
    return this.http.post(this.urls.xman, getContent, { responseType: 'text' }).map(res => {
      const transformedRes = new XmlToJsonPipe().transform(res);
      return transformedRes;
    });
  }

  launchRMM(ServerId, MessageIdentifier) {
    console.log('Lang code ', this.user.getUser().LangCode);

    let url = this.rmmURL;
    url += `?Loginname=${this.user.getUser().LoginName}`;
    url += `&ServerID=${ServerId}`;
    url += `&ul=${this.user.getUser().LangCode}`;
    url += `&RMMGuid=${MessageIdentifier}`;
    url += `&clientTypeId=1&f_connectionId=&directLaunch=`;
    return url;
  }
}
