import { Injectable } from '@angular/core';

@Injectable()
export class FlashDetectService {

  hasFlash = false;

  constructor() { }

  isFlashEnabled() {
    this.hasFlash = false;
    if (navigator.mimeTypes && navigator.mimeTypes['application/x-shockwave-flash'] !== undefined) {
      this.hasFlash = true;
    }
    return this.hasFlash;
  }

}
