import { Injectable, Injector } from '@angular/core';
import {
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpResponse,
    HttpErrorResponse
} from '@angular/common/http';
import { AuthService } from './auth.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class AuthInterceptorService implements HttpInterceptor {

    constructor(public inj: Injector) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const auth = this.inj.get(AuthService);
        if (!request.url.match(/cms1.dmgamingsystems.com/g) && !request.url.match(/xplay2.gameassists.it/g)) {            
            request = request.clone({
                setHeaders: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Authorization': `${auth.token}`,
                    'API-Key': (<any>window).global.variables.apikey
                }
            });
        }

        return next.handle(request);
            // .do((ev: HttpEvent<any>) => { })
            // .catch((response: any) => {
            //     if (response instanceof HttpErrorResponse) {
            //         console.log('response in the catch: ', response);
            //         console.error('Unexpected Error', response.message);
            //     }

            //     return Observable.throw(response);
            // });
    }
}
