import { TestBed, inject } from '@angular/core/testing';

import { CookieBarService } from './cookie-bar.service';

describe('CookieeBarService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CookieBarService]
    });
  });

  it('should be created', inject([CookieBarService], (service: CookieBarService) => {
    expect(service).toBeTruthy();
  }));
});
