import { Directive, ElementRef, Output, EventEmitter, Input, AfterViewInit } from '@angular/core';
import { GameService } from '../services/game.service';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
@Directive({
  selector: '[appLazyLoad]'
})
export class LazyLoadDirective implements AfterViewInit {
  @Output() newGames = new EventEmitter();
  @Input() gameCat;
  @Input() full;
  lastScrollTop = 0;
  skip = 30;
  currentQueue = [this.skip];
  currentRequest: any = 0;
  stop = false;
  constructor(private elRef: ElementRef, private game: GameService) { }

  gameRequestLoop() {
    if (this.game.getGamesRepo(this.gameCat) !== undefined) {
      if (this.currentRequest !== this.currentQueue[0]) {
        this.currentRequest = this.currentQueue[0];
        this.game.getGames(this.currentQueue[0], 30, null, this.gameCat).subscribe(
          res => {
            if ((<any>res).length === 0) {
              this.stop = true;
            }
            this.skip = this.currentQueue[1];
            this.newGames.emit(res);
          },
          err => { }
        );
      }

    }
  }

  queueHandler() {
    this.currentQueue = [this.skip];
    this.currentQueue.push(this.skip + 30);
    if (this.currentQueue.length > 4) {
      this.currentQueue.slice(0, 4);
    }
    this.gameRequestLoop();
  }

  lazyLoadCheck() {
    const windowView = window.pageYOffset + window.innerHeight;
    const footer = this.elRef.nativeElement.offsetTop;
    const st = window.pageYOffset || document.documentElement.scrollTop;
    if (st > this.lastScrollTop && windowView - 200 >= footer || windowView <= footer) {
      this.queueHandler();
    }
    this.lastScrollTop = st;
  }

  ngAfterViewInit() {
    this.queueHandler();
    if (this.full) {
      const lazyLoadInt = setInterval(() => {
        if (this.stop) {
          clearInterval(lazyLoadInt);
        }
        this.queueHandler();
      }, 1000);
      window.addEventListener('scroll', () => {
        if (!this.stop) {
          this.queueHandler();
        }
      });
    }
  }
}

