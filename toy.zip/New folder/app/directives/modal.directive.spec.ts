import { ModalDirective } from './modal.directive';

describe('ModalDirective', () => {
  it('should create an instance', () => {
    const directive = new ModalDirective();
    expect(directive).toBeTruthy();
  });
});
