import { Directive, ElementRef, HostListener, Output, EventEmitter, Input } from '@angular/core';
import { MotdService } from '../services/motd.service';
import { ModalService } from '../services/modal.service';
import { UserService } from '../services/user.service';

@Directive({
  selector: '[appSliderHandler]'
})
export class SliderHandlerDirective {
  @Output() gameLaunchId = new EventEmitter<any>();
  @Output() moreInfo = new EventEmitter<any>();
  @Output() OpenUrl = new EventEmitter<any>();
  @Input() MotdInputObject: any;
  element: any;
  renderer: any;
  moreInfoContent: any;
  modals = [];

  constructor(private motdService: MotdService, private modal: ModalService, private user: UserService, private elementRef: ElementRef) { }

  @HostListener('window:message', ['$event'])
  onWindowMessage(event: any) {
    // Web pack test - this may be unused during production
    if (event.data.type !== 'webpackOk' && event.data.type !== 'webpackClose') {
      const firstChar = event.data.substring(0, 1);
      const lastChar = event.data.substring(event.data.length - 1);
      if (firstChar === '{' && lastChar === '}') {
        const postMessageObject = JSON.parse(event.data);
        console.log(postMessageObject.method);
        switch (postMessageObject.method) {
          case 'launchBanking': {
            this.modal.open('banking', '');
            break;
          }
          case 'launchMPV': {
            console.log('launchMPV', postMessageObject.obj.mpvid);
            break;
          }
          case 'moreInfo': {
            this.modal.open('moreInfo', '');
            this.motdService.getMotdInformation(this.MotdInputObject.MotdId, this.MotdInputObject.ContentPath, `moreInfo.xml`)
              .subscribe(data => {
                this.modal.setContent(data);
              }, error => {
                console.log(error);
              });
            break;
          }
          case 'launchGame': {
            this.gameLaunchId.emit(postMessageObject.obj.gameid);
            break;
          }
          case 'promoOpt': {
            console.log('promoOpt', postMessageObject.obj);
            break;
          }
          case 'openUrl': {
            this.modal.open('openUrl', postMessageObject.obj.url);
            console.log('OpenUrl', postMessageObject.obj);
            break;
          }
          default: {
            break;
          }
        }
      }
    }
  }

}
