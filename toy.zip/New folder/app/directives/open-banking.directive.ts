import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appOpenBanking]'
})

export class OpenBankingDirective {

  @HostListener('click', ['$event']) onClick($event){
    console.log('Open banking');
  }  

  constructor() {
  }

}
