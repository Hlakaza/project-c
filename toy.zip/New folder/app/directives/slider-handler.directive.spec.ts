import { SliderHandlerDirective } from './slider-handler.directive';

describe('SliderHandlerDirective', () => {
  it('should create an instance', () => {
    const directive = new SliderHandlerDirective();
    expect(directive).toBeTruthy();
  });
});
