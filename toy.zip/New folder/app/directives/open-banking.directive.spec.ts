import { OpenBankingDirective } from './open-banking.directive';

describe('OpenBankingDirective', () => {
  it('should create an instance', () => {
    const directive = new OpenBankingDirective();
    expect(directive).toBeTruthy();
  });
});
