import { Directive, ElementRef, HostListener, OnDestroy, Input } from '@angular/core';
import { ModalService } from '../services/modal.service';

@Directive({
  selector: '[appModal]'
})
export class ModalDirective implements OnDestroy {
  element: any;
  @Input() modalGameId = '';
  @Input() modalBgUrl = '';
  constructor(private el: ElementRef, private modal: ModalService) {
    this.element = el.nativeElement;
  }

  ngOnit() {
    // console.log(this.element);
  }

  @HostListener('click', ['$event.target'])
  onClick(btn) {
    if (this.element.getAttribute('modal-open')) {

      if (this.element.getAttribute('modal-tab-index') !== null) {
        this.open(this.element.getAttribute('modal-open'), this.element.getAttribute('modal-tab-index'));
      } else {
        this.open(this.element.getAttribute('modal-open'), this.modalGameId);
      }
    } else if (this.element.getAttribute('modal-close')) {
      this.close(this.element.getAttribute('modal-close'));
    }
  }

  open(modalId: string, bgUrl: string) {
    this.modal.open(modalId, bgUrl);
  }

  close(modalId) {
    this.modal.close(modalId);
  }

  ngOnDestroy() {
    this.modal.clearAll();
  }
}
