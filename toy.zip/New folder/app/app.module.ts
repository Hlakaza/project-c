import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes, ActivatedRouteSnapshot } from '@angular/router';

// Interceptor
import { AuthInterceptorService } from './services/authInterceptor.service';
// Services
import { AuthService } from './services/auth.service';
import { AccountService } from './services/account.service';
import { ChatService } from './services/chat.service';
import { GameService } from './services/game.service';
import { MotdService } from './services/motd.service';
import { UserService } from './services/user.service';
import { ModalService } from './services/modal.service';
import { ContentService } from './services/content.service';
import { RegistrationService } from './services/registration.service';
import { RmmService } from './services/rmm.service';
import { GlobalInfoService } from './services/global-info.service';
import { RouteDataService } from './services/route-data.service';
import { FlashDetectService } from './services/flash-detect.service';
import { BankingService } from './services/banking.service';
// Components
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { ContentComponent } from './components/content/content.component';
import { BannerComponent } from './components/banner/banner.component';
import { GamesComponent } from './components/content/games/games.component';
import { SliderComponent } from './components/slider/slider.component';
import { ModalComponent } from './components/modal/modal.component';
import { TabsComponent } from './components/tabs/tabs.component';
import { TabComponent } from './components/tabs/tab.component';
import { DocumentVerificationComponent } from './components/account/document-verification/document-verification.component';
import { HistoryComponent } from './components/account/history/history.component';
import { InboxComponent } from './components/account/inbox/inbox.component';
import { BalancesComponent } from './components/account/balances/balances.component';
import { ProfileComponent } from './components/account/profile/profile.component';
import { RewardsComponent } from './components/account/rewards/rewards.component';
import { ResponsibleGamingComponent } from './components/account/responsible-gaming/responsible-gaming.component';
import { LoginComponent } from './components/login/login.component';
import { GamesLayoutComponent } from './components/content/games/games-layout/games-layout.component';
import { GameOverlayComponent } from './components/content/games/game-overlay/game-overlay.component';
import { GameTileComponent } from './components/content/games/game-tile/game-tile.component';
import { RegisterComponent } from './components/register/register.component';
import { RegStep1Component } from './components/register/reg-step-1/reg-step-1.component';
import { RegStep2Component } from './components/register/reg-step-2/reg-step-2.component';
import { RegStep3Component } from './components/register/reg-step-3/reg-step-3.component';
import { RegStep4Component } from './components/register/reg-step-4/reg-step-4.component';
import { RegStepEndComponent } from './components/register/reg-step-end/reg-step-end.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { NavigationBlockComponent } from './components/navigation-block/navigation-block.component';
import { ChatComponent } from './components/chat/chat.component';
import { CopyComponent } from './components/content/copy/copy.component';
import { UploadComponent } from './components/account/document-verification/upload/upload.component';
import { BankingComponent } from './components/banking/banking.component';
// Pipes
import { XmlToJsonPipe } from './pipes/xml-to-json.pipe';
import { SafePipe } from './pipes/safe.pipe';
// Directives
import { OpenBankingDirective } from './directives/open-banking.directive';
import { SliderHandlerDirective } from './directives/slider-handler.directive';
import { LazyLoadDirective } from './directives/lazy-load.directive';
import { ModalDirective } from './directives/modal.directive';
// Cookies
import { CookieService } from 'ngx-cookie-service';
import { PromotionBlocksComponent } from './components/promotion-blocks/promotion-blocks.component';
import { CookieBarService } from './services/cookie-bar.service';
import { SearchComponent } from './components/search/search.component';
import { SiteMapComponent } from './components/site-map/site-map.component';
import { LoaderComponent } from './components/loader/loader.component';
import { SnackbarComponent } from './components/snackbar/snackbar.component';

const routes: Routes = [
  { path: '', component: AppComponent, pathMatch: 'full' }
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    ContentComponent,
    ChatComponent,
    BannerComponent,
    GamesComponent,
    SliderComponent,
    ModalComponent,
    TabsComponent,
    TabComponent,
    XmlToJsonPipe,
    SafePipe,
    DocumentVerificationComponent,
    HistoryComponent,
    InboxComponent,
    BalancesComponent,
    ProfileComponent,
    RewardsComponent,
    ResponsibleGamingComponent,
    OpenBankingDirective,
    LoginComponent,
    GamesLayoutComponent,
    GameTileComponent,
    SliderHandlerDirective,
    GameOverlayComponent,
    LazyLoadDirective,
    RegisterComponent,
    RegStep1Component,
    RegStep2Component,
    RegStep3Component,
    RegStep4Component,
    RegStepEndComponent,
    ForgotPasswordComponent,
    NavigationBlockComponent,
    ChatComponent,
    ModalDirective,
    CopyComponent,
    UploadComponent,
    PromotionBlocksComponent,
    SearchComponent,
    SiteMapComponent,
    LoaderComponent,
    SnackbarComponent,
    BankingComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule,
    RouterModule.forRoot(
      routes
    ),
    FormsModule
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: AuthInterceptorService,
    multi: true,
  },
    AuthService,
    AccountService,
    MotdService,
    GameService,
    UserService,
    ModalService,
    ContentService,
    CookieService,
    CookieBarService,
    RegistrationService,
    RmmService,
    GlobalInfoService,
    RouteDataService,
    FlashDetectService,
    BankingService,
    ChatService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
