﻿
var userObj = JSON.parse(localStorage.getItem('vdvUser'));
var userBankingObj = {};
var postParams = 'BrandCode='+ userObj.BrandCode + '&'+'CultureCode='+ userObj.CultureCode + '&' + 'JsonToken=' + userObj.AuthToken;
var AjaxUrl = 'http://api.gmgamingsystems.com.dev.labenv/api/v1.0/Banking/MobileDetails?'+'BrandCode='+ userObj.BrandCode + '&'+'CultureCode='+ userObj.CultureCode;
var mobileBankingSelector = '#mobileBankingContent';
(function _MgsMobileBanking(promotionId) {
    fetch(AjaxUrl , {
        headers: { 'Authorization' : userObj.AuthToken }
    })
    .then(response => response.json())
    .then(data => {
        bankingLaunch(data);
    })
    .catch(err => {
        console.error('An error ocurred', err);
    });

    if(!promotionId) {
        promotionId = "DEFAULT-MOBILE-BANKING-LAUNCH";
    }

    if (typeof displaySwiftRegistration === "function") {
        displaySwiftRegistration();
        return;
    }
   
    function bankingLaunch(data) {
        userBankingObj = data;
        console.log('bankingLaunch',userBankingObj);
        $(mobileBankingSelector).formsService('banking', {
            serviceUrl: userBankingObj.ServiceUrl,
            CasinoId: userBankingObj.CasinoId,
            LanguageCode: userBankingObj.LanguageCode,
            LoginName: userBankingObj.LoginName,
            Password: userBankingObj.Password,
            UserId: userBankingObj.UserId,
            ClientTypeId: userBankingObj.ClientTypeId,
            MOTD : encodeURIComponent(promotionId.toString())
        },
            [
                {
                    event: 'backToGamesCallback',
                    callBack: function () {
                        window.location = "/";
                    }
                },
                {
                    event: 'getFormCallback',
                    callBack: function (result) {

                        $(mobileBankingSelector).show();
                        $("#contentWrapper, .accountBlock").hide();
                        try {
                            window.CloseMenu();
                            window.hideWelcomeBonus();
                        } catch(e) {
                            console.log(e);
                        };

                        try {
                            if (typeof window.CustomEvents.MobileBankingLoadedCallback == 'function') {
                                window.CustomEvents.MobileBankingLoadedCallback();
                            }
                        } catch(e) {
                            console.log(e);
                        };
                    }
                },
                {
                    event: 'processFormCallback',
                    callBack: function (result) {

                    }
                }
            ],
            [{ Name: 'ShowBackNav', Val: 'true' }]);
    }

    function accesBankingInfo() {
        return $.ajax({
            type: "POST",
            url: AjaxUrl.userBankingObj,
            data: postParams,
            dataType: "json",
            error: function (data) {
                $(mobileBankingSelector).hide();
                console.log(data);
            }
        });
    }

    if (postParams) {
        if (!userBankingObj) {
            accesBankingInfo().then(bankingLaunch);
        } else {
            // bankingLaunch();
        }
    } else {
        alert('Missed');
    }
})();